using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using testAPI.Interface;

namespace testAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CRUDController : ControllerBase
    {
        
        private readonly ILoginService _loginService;

        public CRUDController(ILoginService loginService)
        {
            _loginService = loginService;   
        }

        [HttpGet]

        public async Task<IActionResult> GetAllLoginData()
        {
            var val = await _loginService.GetAllLoginData();
            return Ok(val);
        }

        // [HttpGet("{id/int}")]
        // public async Task<IActionResult> GetLogin(int Id)
        // {
        //     var val = await _loginService.GetLogin(Id);
        //     return Ok(val);
        // }

        // [HttpPost]
        // public async Task<IActionResult> InsertLoginDetails(Login login)
        // {
        //     var val = await _loginService.InsertLoginDetails(login);
        //     return Ok(val);
        // }

        // [HttpPost]
        // public async Task<IActionResult> DeleteLoginDetails(int id)
        // {
        //     var val = await _loginService.DeleteLoginDetails(id);
        //     return Ok(val);
        // }
    }
}