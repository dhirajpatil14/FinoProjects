using System.Security.AccessControl;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testAPI.Interface;
using Npgsql;
using testAPI.Models;
using System.Data;

namespace testAPI.Repository
{
    public class LoginRepository : ILoginRepository
    {
        private readonly IConfiguration _config;
        public LoginRepository(IConfiguration config)
        {
            _config = config;
        }

        public async Task<DataTable> GetAllLoginData()
        {
            var connStr = _config.GetConnectionString("login");
            using(var connection = new NpgsqlConnection(connStr))
            {
                connection.Open();
                using(var command = new NpgsqlCommand("SELECT id, name, dob, mobile, age, gender FROM public.login;", connection))
                {
                    using (var adapter =  new NpgsqlDataAdapter(command))
                    {
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        return dataTable;
                    }
                }
            }
        }
    }
}