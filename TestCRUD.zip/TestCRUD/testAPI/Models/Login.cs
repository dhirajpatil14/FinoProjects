using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace testAPI.Models
{
    public interface ILogin {
        public int  Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Mobile { get; set; }
        public string Gender { get; set; }
        public string Age {get; set;}
    }
    public class Login : ILogin
    {
        public int  Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Mobile { get; set; }
        public string Gender { get; set; }
        public string Age {get; set;}
    }
}