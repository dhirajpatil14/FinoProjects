using System.Dynamic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testAPI.Interface;
using testAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;


namespace testAPI.Service
{
    public class LoginService : ILoginService
    {
        private readonly ILoginRepository _loginRepo;
        public LoginService(ILoginRepository loginRepo)
        {
            _loginRepo = loginRepo;
        }

        public async Task<IEnumerable<ILogin>> GetAllLoginData() 
        {
            var data = await _loginRepo.GetAllLoginData();
            return data?.AsEnumerable().Select(row => new Login
            {
                Id = Convert.ToInt32(row["id"]),
                Name = Convert.ToString(row["name"]),
                DOB = Convert.ToDateTime(row["dob"]),
                Mobile = Convert.ToString(row["mobile"]),
                Age = Convert.ToString(row["age"]),
                Gender = Convert.ToString(row["gender"]),
            });
            // return data;
        }

        public async Task<ILogin> GetLogin(int Id)
        {
            return null;
        }
        public async Task<ILogin> InsertLoginDetails(Login login)
        {
            return null;
        }

        public async Task<ILogin> DeleteLoginDetails(int Id)
        {
            return null;
        }
    }
}