using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using testAPI.Models;
using Microsoft.AspNetCore.Mvc;


namespace testAPI.Interface
{
    public interface ILoginService
    {
        Task<IEnumerable<ILogin>> GetAllLoginData();
        Task<ILogin> GetLogin(int Id);
        Task<ILogin> InsertLoginDetails(Login login);
        Task<ILogin> DeleteLoginDetails(int Id);
    }
}