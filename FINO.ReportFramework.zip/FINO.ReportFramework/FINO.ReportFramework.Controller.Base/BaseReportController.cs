﻿using FINO.CoreProject.BaseController;
using FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder;
using FINO.ReportFramework.Repository.ReportRepository.Base;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.ReportFramework.Entities.Response;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Request;
using Microsoft.AspNetCore.Authorization;

namespace FINO.ReportFramework.Controller.Base
{
    public abstract class BaseReportController<TRepository, TReportBuilder, TReportData> : BaseController<TRepository>
        where TReportData : ReportDataDetails
        where TReportBuilder : ReportQueryBuilder
         where TRepository : ReportRepository<TReportBuilder, TReportData>

    {
        public BaseReportController(TRepository repository) : base(repository) { }

        protected new dynamic New(ILogger logger)
        {
            base.New(logger);
            this._repository.New(logger);
            return this;
        }

        [HttpPost]
        [Route("getfields")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]

        //public abstract Task<ActionResult<Response<ReportFieldResponse>>> GetFields([FromBody] Request<String> request);
        public virtual async Task<ActionResult<Response<ReportFieldResponse>>> GetFields([FromBody] RequestWithRequestIdImpl<String> request)
        {
            return Ok( await this._repository.GetFieldList());
        }

        [HttpPost]
        [Route("getdata")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        //public abstract Task<Response<ReportResponse>> ExecuteReport(Request<FilterRequest> request, HeaderEntity header);
        public virtual async Task<ActionResult<Response<ReportResponse>>> GetData([FromHeader(Name ="X-Header")] HeaderEntity header
            , [FromBody] RequestWithRequestIdImpl<FilterRequest> request)
        {
            
            return Ok(await this._repository.ExecuteReport(request,header));
        }
    }
}
