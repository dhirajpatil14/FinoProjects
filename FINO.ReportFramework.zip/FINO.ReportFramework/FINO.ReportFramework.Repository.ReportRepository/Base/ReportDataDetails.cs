﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.ReportRepository.Base
{
    public interface ReportDataDetails : BaseRepository
    {
        new dynamic New();
        QueryDataEntity ReportFieldsDefination();
        QueryDataEntity GetReportFields();
        IEnumerable<DisplayFieldEntity> GetFields();
    }
}
