﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.ReportRepository.Base
{
    public abstract class ReportDataDetailsImpl : BaseRepositoryImpl, ReportDataDetails
    {
        public static QueryDataEntity ReportFields { get; private set; }

        public new dynamic New()
        {
            GetReportFields();
            return this;
        }

        public abstract QueryDataEntity ReportFieldsDefination();

        public QueryDataEntity GetReportFields()
        {
            if(ReportFields == null)
            {
                ReportFields = ReportFieldsDefination();
            }
            if(ReportFields == null)
            {
                throw new NotImplementedException();
            }
            return ReportFields;
        }

        public IEnumerable<DisplayFieldEntity> GetFields()
        {
            if (ReportFields == null)
            {
                throw new NotImplementedException();
            }
            return (from data in ReportFields.fields.Values select (DisplayFieldEntity)data);
        }
    }
}
