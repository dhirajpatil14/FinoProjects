﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Request;
using Microsoft.Extensions.Logging;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Entities.Response;
using FINO.ReportFramework.Entities.Field;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.CoreProject.Enums;

namespace FINO.ReportFramework.Repository.ReportRepository.Base
{
    public abstract class ReportRepositoryImpl<TReportBuilder,TReportData > : BaseRepositoryWithLoggerImpl,ReportRepository<TReportBuilder,TReportData>
       where TReportData : ReportDataDetails
       where TReportBuilder : ReportQueryBuilder.QueryBuilder.ReportQueryBuilder
    {
        private static TReportData _reportDataDetails;
        private static TReportBuilder _reportBuilder; 

        public TReportData ReportDataDetails { get{ return _reportDataDetails; } }

        public TReportBuilder ReportBuilder { get { return _reportBuilder; } }
        public new dynamic New(ILogger logger, TReportData reportDataDetails, TReportBuilder reportBuilder)
        {
            base.New(logger);
            _reportDataDetails = reportDataDetails;
            reportBuilder.New(logger, reportDataDetails.New().GetReportFields());
            _reportBuilder = reportBuilder;
            return this;
        }

        public abstract Task<Response<ReportResponse>> ExecuteReport(RequestWithRequestId<FilterRequest> request, HeaderEntity header);

        public abstract Task<Response<ReportFieldResponse>> GetReportFields(RequestWithRequestId<String> request);


        //public abstract Task<>

        protected override void Dispose(bool disposing)
        {
            if (this.ReportDataDetails != null)
            {
                this.ReportDataDetails.Dispose();
            }
            if(this.ReportBuilder != null)
            {
                this.ReportBuilder.Dispose();
            }  
            base.Dispose(disposing);
        }
        public QueryEntity GetQueries(FilterRequest request, HeaderEntity header)
        {
            return this.ReportBuilder.CreateQueryForExecution(request, header);
        }

        public String ResetQueryForPage(PageEntity page)
        {
            return this.ReportBuilder.ResetQueryForPage(page);
        }

        public virtual async Task<ReportFieldResponse> GetFieldList()
        {
            return await Task.Run(() => {
                var fields = this.ReportDataDetails.GetFields();
                return new ReportFieldResponseImpl { fields = fields };
            });
        }
        
        protected virtual async  Task<ReportResponse> ProcessFilterRequest(FilterRequest request,HeaderEntity header) {
          //  var response = new FilterResponseImpl<String>();
            var queries = this.ReportBuilder.CreateQueryForExecution(request, header);
            if(queries ==null) {
                return null;
            }

            return null;
        }
    }
}
