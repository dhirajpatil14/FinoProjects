﻿using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Entities.Response;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.ReportRepository.Base
{
    public interface ReportRepository<TReportBuilder,TReportData> : BaseRepositoryWithLogger
       where TReportData : ReportDataDetails
       where TReportBuilder : ReportQueryBuilder.QueryBuilder.ReportQueryBuilder
    {
        TReportBuilder ReportBuilder { get; }
        TReportData ReportDataDetails { get; }

        new dynamic New(ILogger logger, TReportData reportDataDetails, TReportBuilder reportBuilder);

        Task<Response<ReportResponse>> ExecuteReport(RequestWithRequestId<FilterRequest> request, HeaderEntity header);
        Task<Response<ReportFieldResponse>> GetReportFields(RequestWithRequestId<String> request);
        Task<ReportFieldResponse> GetFieldList();

    }
}
