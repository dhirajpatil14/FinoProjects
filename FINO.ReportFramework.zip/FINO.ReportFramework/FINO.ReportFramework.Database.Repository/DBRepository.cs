﻿
using FINO.CoreProject.Database.DBRepository.Base;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.CoreProject.Entity.Base;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Runtime.CompilerServices;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace FINO.ReportFramework.Database.Repository
{
    public static class DBRepository 
    {
        private static IConfiguration _configuration;
        public static System.String ConnectionString { get; private set; }
        static DBRepository()
        {
            //_configuration= new ConfigurationBuilder()
            //    .AddJsonFile("dbsettings.json")
            //    .AddEnvironmentVariables()
            //    .Build();
            //if(_configuration != null) ConnectionString = _configuration.GetValue<String>("connectionString");
        }

        /*
        public static async Task<IEnumerable<T>> GetData<T>(String connectionString, String sqlQuery)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                //return await connection.QueryAsync<T>(sqlQuery);
                using(var command = new SqlCommand(sqlQuery))
                {
                    try
                    {
                        //var data = connection.ExecuteReader(sqlQuery);
                        var data = command.ExecuteReader();
                       
                        if (data == null) return null;
                        return null;

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }
        public static async Task<IEnumerable<T>> GetData<T>(String sqlQuery)
        {
            return await GetData<T>(ConnectionString, sqlQuery);
        }

        public static async Task<Int64>  GetCount(String connectionString, String sqlQuery)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                return await connection.QueryFirstAsync<Int64>(sqlQuery);
            }
        }

        public static async Task<Int64> GetCount(String sqlQuery)
        {
            return await GetCount(ConnectionString,sqlQuery);
        }
        */
    }
}
