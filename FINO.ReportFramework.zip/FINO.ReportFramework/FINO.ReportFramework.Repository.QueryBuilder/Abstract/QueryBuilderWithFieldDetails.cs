﻿using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.QueryBuilder.Abstract
{
    public abstract class QueryBuilderWithFieldDetails<TEntity> :QueryBuilder<TEntity>
    {
        public QueryDataEntity QueryData { get; private set; }

        protected override void Dispose(bool disposing)
        {
            if (this.QueryData != null)
            {
                this.QueryData.Dispose();
                this.QueryData = null;
            }
            base.Dispose(disposing);
        }

        protected internal dynamic New(ILogger logger, StringBuilder builder,QueryDataEntity queryData)
        {
            base.New(logger, builder);
            this.QueryData = queryData;
            return this;
        }
    }
}
