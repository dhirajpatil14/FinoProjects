﻿using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.QueryBuilder.Abstract
{
    public abstract class QueryBuilderMultipleOutput<TEntity> : QueryBuilderWithFieldDetails<TEntity>
    {
        public new virtual StringBuilder[] GetQuery(TEntity request) { return null; }
        public new virtual StringBuilder[] Execute(FilterRequestWithHeader request) { return [this.Builder]; }
    }
}
