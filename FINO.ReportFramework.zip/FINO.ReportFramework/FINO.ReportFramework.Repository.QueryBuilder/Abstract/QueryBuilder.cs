﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Request;
using System.Text;
using Microsoft.Extensions.Logging;


namespace FINO.ReportFramework.Repository.QueryBuilder.Abstract
{
    public abstract class QueryBuilder<TEntity> : BaseRepositoryWithLoggerImpl,BaseRepositoryWithLogger
    {
        public StringBuilder Builder { get; private set; }

        protected override void Dispose(bool disposing)
        {
            if(this.Builder != null)
            {
                this.Builder.Clear();
                this.Builder = null;
            }
            base.Dispose(disposing);
        }
        protected internal dynamic New(ILogger logger,StringBuilder builder)
        {
            base.New(logger);
            this.Builder = builder;
            return this;
        }
        public virtual StringBuilder Execute(FilterRequestWithHeader request) { return this.Builder; }
        public virtual StringBuilder GetQuery(TEntity request) { return null; }
        protected abstract void CreateQuery(params StringBuilder[] result);
        public abstract void SetQuery(TEntity data);
    }
}
