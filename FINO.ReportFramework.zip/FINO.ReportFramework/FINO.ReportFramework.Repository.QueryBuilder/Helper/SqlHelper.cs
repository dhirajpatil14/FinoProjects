﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Enums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.QueryBuilder.Helper
{
    public static class SqlHelper
    {
        public const String ORDER_BY ="ORDER BY";
        public const String DECLARE ="DECLARE";
        public const String SELECT = "SELECT";
        public const String WHERE = "WHERE";
        public const String FROM = "FROM";
        public const String COUNT = "COUNT";
        public const String OFFSET = "OFFSET";
        public const String ROWS = "ROWS";
        public const String FETCH_NEXT = "FETCH NEXT";
        public const String ROWS_ONLY = "ROWS ONLY";
        public const String SELECT_ALL = "*";
        public const String LIKE = "LIKE";
        public const String BEGIN = "BEGIN";
        public const String END = "END";
        public const String TOP = "TOP";
        
        public static String getConditionTypeSqlCommand(ConditionType conditionType) => (conditionType == ConditionType.AND ? "AND" : "OR");
        public static String getSortTypeSqlCommand(SortType sortType) => (sortType == SortType.Ascending ? "ASC" : "DESC");


        internal static String getOperatorTypeNonStringSqlCommand(OperatorType operatorType)
        {
            var strOperator = String.Empty;
            switch (operatorType)
            {
                case OperatorType.EQUALS:
                    {
                        strOperator = " = ";
                        break;
                    }
                case OperatorType.NOT_EQUAL:
                    {
                        strOperator = " != ";
                        break;
                    }
                case OperatorType.GREATER_THAN:
                    {
                        strOperator = " > ";
                        break;
                    }
                case OperatorType.LESS_THAN:
                    {
                        strOperator = " < ";
                        break;
                    }
                case OperatorType.LESS_THAN_EQUALS:
                    {
                        strOperator = " <= ";
                        break;
                    }
                case OperatorType.GREATER_THAN_EQUALS:
                    {
                        strOperator = " >= ";
                        break;
                    }
                default:
                    {
                        strOperator = " = ";
                        break;
                    }
            }
            return strOperator;
        }

        internal static Boolean dbTypeString(SqlDbType dbtype)
        {
            if (dbtype == SqlDbType.NChar
                || dbtype == SqlDbType.NVarChar
                || dbtype == SqlDbType.VarChar
                || dbtype == SqlDbType.Char
                || dbtype == SqlDbType.NText
                || dbtype == SqlDbType.Text
                || dbtype == SqlDbType.NText
                )
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        internal static Boolean sqldbTypeUsingSingleQuote(SqlDbType dbType)
        {
            if (dbTypeString(dbType)
                || dbType == SqlDbType.Binary
                || dbType == SqlDbType.Char
                || dbType == SqlDbType.Date
                || dbType == SqlDbType.DateTime
                || dbType == SqlDbType.DateTime2
                || dbType == SqlDbType.SmallDateTime
                || dbType == SqlDbType.DateTimeOffset
                || dbType == SqlDbType.Image
                || dbType == SqlDbType.NChar
                || dbType == SqlDbType.NText
                || dbType == SqlDbType.NVarChar
                || dbType == SqlDbType.Text
                || dbType == SqlDbType.Time
                || dbType == SqlDbType.Timestamp
                || dbType == SqlDbType.Udt
                || dbType == SqlDbType.UniqueIdentifier
                || dbType == SqlDbType.VarBinary
                || dbType == SqlDbType.VarChar
                || dbType == SqlDbType.Variant
                || dbType == SqlDbType.Xml
             )
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        internal static Boolean stringContainsOperator(OperatorType operatorType)
        {
            if (operatorType == OperatorType.CONTAINS
                || operatorType == OperatorType.START_WITH
                || operatorType == OperatorType.ENDS_WITH)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        internal static String getOperatorTypeSqlCommand(OperatorType operatortype , String field , String value) {
            var strresult = String.Empty;
            switch(operatortype)
            {
                case OperatorType.CONTAINS:
                    {
                        strresult = String.Format(" {0} {1} '%{2}%'", field, LIKE, value);
                        break;
                    }
                case OperatorType.START_WITH:
                    {
                        strresult = String.Format(" {0} {1} '{2}%'", field,LIKE, value);
                        break;
                    }
                case OperatorType.ENDS_WITH:
                    {
                        strresult = String.Format(" {0} {1} '%{2}'", field,LIKE, value);
                        break;
                    }
                default:
                    {
                        strresult = String.Format(" {0} {1} {2}", field, getOperatorTypeNonStringSqlCommand(operatortype), value);
                        break;
                    }
            }
            return strresult;
        }
    }
}
