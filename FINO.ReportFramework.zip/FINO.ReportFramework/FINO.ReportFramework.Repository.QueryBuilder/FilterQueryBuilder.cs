﻿using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Filter;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Enums;
using FINO.ReportFramework.Repository.QueryBuilder.Abstract;
using FINO.ReportFramework.Repository.QueryBuilder.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace FINO.ReportFramework.Repository.QueryBuilder
{
    public class FilterQueryBuilder : QueryBuilderMultipleOutput<IEnumerable<FilterEntity>>
    {
        public FilterQueryBuilder() {

            DeclareParametersBuilder = new StringBuilder();
        }
        public StringBuilder DeclareParametersBuilder { get; private set; }

        public new dynamic New(ILogger logger, StringBuilder builder, QueryDataEntity queryData)
        {
            base.New(logger, builder, queryData);
            return this;
        }
        protected override void Dispose(bool disposing)
        {
            if(this.DeclareParametersBuilder != null)
            {
                this.DeclareParametersBuilder.Clear();
                this.DeclareParametersBuilder = null;
            }
            base.Dispose(disposing);
        }
        public override StringBuilder[] GetQuery(IEnumerable<FilterEntity> request)
        {
            StringBuilder strBldr=new StringBuilder() , strDeclareBldr = new StringBuilder();
            try
            {
                if(request == null 
                    || request.Count() <=0) {
                    return [strBldr,
                        strDeclareBldr];
                }
                var requestList = request.Select((x, i) => new { data = x, index = i }).ToList();
                foreach (var filterEntity in requestList)
                {
                    var fieldDetail = this.QueryData.fields[filterEntity.data.field];

                    if (requestList.Count > 1 
                        && (filterEntity.data.condition == ConditionType.AND  
                        || filterEntity.index ==0)
                        && (filterEntity.index + 1 < requestList.Count-1)
                        && requestList[filterEntity.index +1].data.condition == ConditionType.OR)
                    {
                        strBldr.Append(" ( ");
                    }                        
                    if (filterEntity.index !=0) {

                        if (filterEntity.data.condition == ConditionType.AND
                        && requestList[filterEntity.index - 1].data.condition == ConditionType.OR)
                        {
                            strBldr.Append(" ) ");
                        }

                        strBldr.AppendFormat(" {0} ", SqlHelper.getConditionTypeSqlCommand(filterEntity.data.condition));
                        strDeclareBldr.Append(" , ");
                    }

                    strDeclareBldr.AppendFormat(" {0} AS {1} ", fieldDetail.declareVariable.ToUpper(), fieldDetail.dbType);
                    if (SqlHelper.dbTypeString(fieldDetail.dbType))
                    {
                        strDeclareBldr.AppendFormat("({0})", (fieldDetail.size != null ? fieldDetail.size : 0));
                    }

                    if (SqlHelper.sqldbTypeUsingSingleQuote(fieldDetail.dbType))
                    {
                        strDeclareBldr.AppendFormat(" = '{0}' ", filterEntity.data.value);
                    }
                    else
                    {
                        strDeclareBldr.AppendFormat(" = {0} ", filterEntity.data.value);
                    }

                    if (!SqlHelper.stringContainsOperator(filterEntity.data.operatorType)) 
                    {
                        strBldr.AppendFormat(" {0} {1} {2}", fieldDetail.dbField.ToUpper(),  
                            SqlHelper.getOperatorTypeNonStringSqlCommand(filterEntity.data.operatorType)
                            , fieldDetail.declareVariable.ToUpper());
                    }
                    else 
                    {
                        var strqury = String.Empty;
                        if (filterEntity.data.operatorType == OperatorType.ENDS_WITH 
                            || filterEntity.data.operatorType == OperatorType.CONTAINS)
                        {
                            strqury = "'%' + ";
                        }
                        
                        strqury = $"{strqury}{fieldDetail.declareVariable.ToUpper()}";

                        if (filterEntity.data.operatorType == OperatorType.START_WITH
                            || filterEntity.data.operatorType == OperatorType.CONTAINS)
                        {
                            strqury = $"{strqury} + '%' ";
                        }
                        strBldr.AppendFormat(" {0} LIKE ({1})", fieldDetail.dbField.ToUpper(),strqury);
                    }
                }
                if (requestList[requestList.Count - 1] != null 
                    && requestList[requestList.Count - 1].data !=null 
                    && requestList[requestList.Count - 1].data.condition == ConditionType.OR) {
                    strBldr.Append(" ) ");
                }
                return [strBldr,
                    strDeclareBldr];
            }
            finally
            {
                strBldr = null;
                strDeclareBldr = null;
            }
        }

        public override StringBuilder[] Execute(FilterRequestWithHeader request)
        {
            if(request==null || request.request==null || request.request.filters == null)
            {
                return [Builder,
                    DeclareParametersBuilder];

            }
            CreateQuery(this.GetQuery(request.request.filters));
            return [Builder,
                DeclareParametersBuilder];
        }
        public override void SetQuery(IEnumerable<FilterEntity> data)
        {
            CreateQuery( this.GetQuery(data));
        }

        protected override void CreateQuery(params StringBuilder[] result)
        {
            if (result == null
                || result.Length < 2)
            {
                return;
            }

            if (result[0].Length > 0 && Builder.Length > 0) this.Builder.AppendLine();
            if (this.Builder.Length > 0) Builder.AppendLine();
            this.Builder.Append(result[0]);

            if (result[1].Length > 0 && DeclareParametersBuilder.Length > 0) DeclareParametersBuilder.AppendLine();
            if (this.DeclareParametersBuilder.Length > 0) DeclareParametersBuilder.AppendLine();
            this.DeclareParametersBuilder.Append(result[1]);
        }
    }
}
