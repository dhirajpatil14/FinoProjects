﻿using System.Text;
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Filter;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Enums;
using FINO.ReportFramework.Repository.QueryBuilder.Abstract;
using FINO.ReportFramework.Repository.QueryBuilder.Helper;
using Microsoft.Extensions.Logging;


namespace FINO.ReportFramework.Repository.QueryBuilder
{
    public class SortQueryBuilder : QueryBuilderWithFieldDetails<IDictionary<String,SortType>>
    {
        public new dynamic New(ILogger logger, StringBuilder builder, QueryDataEntity queryData)
        {
            base.New(logger, builder, queryData);
            return this;
        }
        public override StringBuilder GetQuery(IDictionary<String, SortType> request)
        {
            StringBuilder strbldr = new StringBuilder();
            try
            {
                if (request == null ||
                    request.Count <= 0)
                {
                    return strbldr;
                }

                foreach (var key in request.Keys)
                {
                    var fieldDetail = this.QueryData.fields[key];
                    if (key != request.First().Key) { strbldr.Append(" , "); }

                    strbldr.AppendFormat(" {0} {1} ", fieldDetail.dbField.ToUpper(), SqlHelper.getSortTypeSqlCommand(request[key]));
                }
                return strbldr;
            }
            finally
            {
                strbldr = null;
            }
        }
        public override StringBuilder Execute(FilterRequestWithHeader request)
        {
            if(request==null 
                || request.request==null 
                || request.request.sort==null)
            {
                return Builder;
            }
            CreateQuery(this.GetQuery(request.request.sort.sort));
            return Builder;
        }

        public override void SetQuery(IDictionary<String, SortType> data)
        {
            CreateQuery(this.GetQuery(data));
        }

        protected override void CreateQuery(params StringBuilder[] result)
        {
            if (result == null || result.Length < 1) return;
            if (result[0].Length > 0 && Builder.Length > 0) Builder.AppendLine();
            if (Builder.Length > 0) Builder.Append(" , ");
            Builder.Append(result[0]);
        }
    }
}
