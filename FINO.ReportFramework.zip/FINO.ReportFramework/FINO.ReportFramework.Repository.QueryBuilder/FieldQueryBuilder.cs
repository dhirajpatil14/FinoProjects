﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;

using FINO.ReportFramework.Repository.QueryBuilder.Abstract;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FINO.ReportFramework.Repository.QueryBuilder
{
    public class FieldQueryBuilder : QueryBuilderWithFieldDetails<IEnumerable<String>>
    {
        public new dynamic New(ILogger logger, StringBuilder builder, QueryDataEntity queryData)
        {
            base.New(logger, builder, queryData);
            return this;
        }
        public override StringBuilder GetQuery(IEnumerable<String> request)
        {
            StringBuilder strbldr = new StringBuilder();
            try
            {
                if (request == null || request.Count() <= 0) return strbldr;
                foreach (String field in request)
                {
                    var fieldDetail = this.QueryData.fields[field];
                    if (field != request.First()) strbldr.Append(",");
                    strbldr.Append(fieldDetail.dbField.ToUpper());
                }
                return strbldr;
            }
            finally
            {
                strbldr = null;
            }
        }
        public override StringBuilder Execute(FilterRequestWithHeader request)
        {
            if (request.header == null)
            {
                return this.Builder;
            }

            CreateQuery( this.GetQuery(request.header.fields));
            return Builder;
        }

        public override void SetQuery(IEnumerable<String> data)
        {
            CreateQuery(this.GetQuery(data));
        }

        protected override void CreateQuery(params StringBuilder[] result)
        {
            if (result == null || result.Length < 1) return;
            if (result[0].Length > 0 && Builder.Length > 0) Builder.AppendLine();
            if (Builder.Length > 0) Builder.Append(" , ");
            Builder.Append(result[0]);
        }
    }
}
