﻿
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Repository.QueryBuilder.Abstract;
using FINO.ReportFramework.Repository.QueryBuilder.Helper;
using Microsoft.Extensions.Logging;
using System.Text;

namespace FINO.ReportFramework.Repository.QueryBuilder
{
    public class PaginationQueryBuilder : QueryBuilder<PageEntity>
    {
        public new dynamic New(ILogger logger, StringBuilder builder)
        {
            base.New(logger, builder);
            return this;
        }
        public override void SetQuery(PageEntity data)
        {
            CreateQuery(this.GetQuery(data));
        }

        public override StringBuilder Execute(FilterRequestWithHeader request)
        {
            if (request == null
                || request.request == null
                || request.request.page == null)
            {
                return Builder;
            }
            CreateQuery(this.GetQuery(request.request.page));
            return Builder;
        }

        protected override void CreateQuery(params StringBuilder[] result)
        {
            if (result == null || result.Length < 1) return;
            if (result[0].Length > 0 && Builder.Length > 0) Builder.AppendLine();
            if (Builder.Length > 0) Builder.Append(" , ");
            Builder.Append(result[0]);
        }
        public override StringBuilder GetQuery(PageEntity request)
        {
            StringBuilder strbldr = new StringBuilder();
            try
            {
                if(request == null
                    || (request.page==0 && request.size==0)) {
                    return strbldr;
                }
                var page = (request.page < 1 ? 0 : request.page - 1);
                var recordNos = (page * request.size);
                if (recordNos < 0) return strbldr;

                strbldr.AppendFormat(" {0} ({1}) {2} ",SqlHelper.OFFSET, recordNos, SqlHelper.ROWS);
                strbldr.AppendLine();
                strbldr.AppendFormat(" {0} {1} {2} " , SqlHelper.FETCH_NEXT,request.size, SqlHelper.ROWS_ONLY);
                return strbldr;
            }
            finally
            {
                strbldr = null;
            }
        }
    }
}
