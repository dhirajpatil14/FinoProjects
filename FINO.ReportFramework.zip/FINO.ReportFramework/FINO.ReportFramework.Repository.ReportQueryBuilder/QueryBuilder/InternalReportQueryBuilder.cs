﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Request;
using System.Text;
using FINO.ReportFramework.Repository.QueryBuilder.Helper;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query;
namespace FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder
{
    public abstract partial class ReportQueryBuilderImpl : BaseRepositoryWithLoggerImpl, ReportQueryBuilder
    {
        protected void initialize(FilterRequestWithHeader request)
        {
            #region DeclareAndFilter
            if (_filterBldr == null || _filterBldr.Length <= 0)
            {
                var filterResult = _filterQueryBuilder.Execute(request);
                if (filterResult != null && filterResult.Length >= 2
                    && (_declareStrBldr == null || _declareStrBldr.Length <= 0))
                {
                    _declareStrBldr = filterResult[1];

                }
            }
            #endregion DeclareAndFilter

            #region Fields
            if (_fieldStrBldr == null || _fieldStrBldr.Length <= 0)
            {
                _fieldQueryBuilder.Execute(request);
            }
            #endregion Fields
            #region Sort
            if (_sortBldr == null || _sortBldr.Length <= 0)
            {
                _sortQueryBuilder.Execute(request);
            }
            #endregion Sort
        }

        protected StringBuilder createQuery(FilterRequestWithHeader request, Boolean countQuery =false)
        {
            if (countQuery 
                && this._maincountQueryStrBldr !=null
                && this._maincountQueryStrBldr.Length > 0)
            {
                return this._maincountQueryStrBldr;
            }
            else if(!countQuery
                && this._mainfullQueryStrBldr != null
                && this._mainfullQueryStrBldr.Length > 0)
            {
                return this._mainfullQueryStrBldr;
            }

            #region AbstractMethods
            this._fromClause = this.FromClause();
            if(this._fromClause == null 
                || this._fromClause == String.Empty
                || this._fromClause.Trim().Length <=0)
            {
                throw new NotImplementedException();
            }
            var strWhereClause = this.WhereClause();
            #endregion AbstractMethods

            var strBldrFull = new StringBuilder();
            var strBldrCount = new StringBuilder();
            var strBldr = new StringBuilder();

            this._mainfullQueryBldrWithoutPage = new StringBuilder();
            this._mainfullQueryStrBldr=new StringBuilder();
            this._maincountQueryStrBldr=new StringBuilder();
            try
            {
                strBldr.AppendFormat("{0} ",SqlHelper.BEGIN);
                strBldr.AppendLine();
                if (_declareStrBldr.Length > 0)
                {
                    strBldr.AppendFormat(" {0} {1};", SqlHelper.DECLARE, _declareStrBldr);
                    strBldr.AppendLine();
                }

                strBldr.AppendFormat(" {0} ", SqlHelper.SELECT);

                strBldrFull.Append(strBldr);
                strBldrCount.Append(strBldr);
                strBldr.Clear();
                
                strBldrCount.AppendFormat(" {0} (1) AS DBCNT ", SqlHelper.COUNT);
                if (_fieldStrBldr.Length > 0)
                {
                    strBldrFull.AppendFormat(" {0} ", _fieldStrBldr);
                }
                else
                {
                    strBldrFull.AppendFormat(" {0} ", SqlHelper.SELECT_ALL);
                }

                strBldr.AppendLine();
                strBldr.AppendFormat(" {0} {1} ", SqlHelper.FROM, this._fromClause.ToUpper());
                strBldr.AppendLine();
                strBldr.AppendFormat(" {0} ( ", SqlHelper.WHERE);
                if (!String.IsNullOrEmpty(strWhereClause))
                {
                    strBldr.AppendFormat(" {0} ", strWhereClause.ToUpper());
                }
                if(_filterBldr.Length > 0)
                {
                    strBldr.AppendFormat(" {0} {1} ",SqlHelper.getConditionTypeSqlCommand(Enums.ConditionType.AND),  _filterBldr);
                }
                strBldr.Append(" )");

                strBldrCount.Append(strBldr);
                strBldrFull.Append(strBldr);
                strBldr.Clear();

                if (_sortBldr.Length > 0)
                {
                    strBldrFull.AppendLine();
                    strBldrFull.AppendFormat(" {0} {1} ", SqlHelper.ORDER_BY, _sortBldr);
                }

                this._mainfullQueryBldrWithoutPage.Append(strBldrFull);

                if (request!=null && request.request !=null && request.request.page != null && request.request.page.size > 0)
                {
                    getQueryPageStatement(request.request.page, strBldrFull);
                }

                getQueryEndStatement(strBldr);

                strBldrCount.Append(strBldr);
                strBldrFull.Append(strBldr);
                strBldr.Clear();

                this._maincountQueryStrBldr.Append(strBldrCount);
                this._mainfullQueryStrBldr.Append(strBldrFull);

                if (countQuery)
                {
                    return this._maincountQueryStrBldr;
                }
                else
                {
                    return this._mainfullQueryStrBldr;
                }
            }
            finally
            {
                strBldr.Clear();
                strBldrFull.Clear();
                strBldrCount.Clear();
                strBldr = null;
                strBldrFull = null;
                strBldrCount = null;
            }
        }

        private StringBuilder getQueryEndStatement(StringBuilder strBldr)
        {
            strBldr.AppendLine(";");
            strBldr.AppendFormat(" {0}", SqlHelper.END );
            return strBldr;
        }

        private StringBuilder getQueryPageStatement(PageEntity page , StringBuilder strBldr)
        {
            strBldr.AppendLine();
            strBldr.AppendFormat(" {0} ", this._pageQueryBuilder.GetQuery(page));
            return strBldr;
        }
    }
}
