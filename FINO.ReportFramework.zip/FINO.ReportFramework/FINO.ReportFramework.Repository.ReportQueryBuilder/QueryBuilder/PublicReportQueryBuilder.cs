﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query;
using System.Text;

namespace FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder
{
    public abstract partial class ReportQueryBuilderImpl : BaseRepositoryWithLoggerImpl, ReportQueryBuilder
    {
        public String GetCountQuery(FilterRequestWithHeader request)
        {
            this.initialize(request);
            return createQuery(request,true).ToString();
        }
        public String GetFullQuery(FilterRequestWithHeader request)
        {
            this.initialize(request);
            return createQuery(request,false).ToString();
        }

        public FilterRequestWithHeader GetFilterRequestWithHeader(FilterRequest request, HeaderEntity header)
        {
            return new FilterRequestWithHeaderImpl
            {
                header = header,
                request = request
            };
        }
        public QueryEntity CreateQueryForExecution(FilterRequest request, HeaderEntity header)
        {
            var filterRequestwitHeader = this.GetFilterRequestWithHeader(request, header);
            var getCountQuery = this.GetCountQuery(filterRequestwitHeader);
            var getSelectQuery = this.GetFullQuery(filterRequestwitHeader);
            return new QueryEntityImpl { CountQuery = getCountQuery, FullQuery = getSelectQuery };
        }

        public String ResetQueryForPage(PageEntity pageEntity)
        {
            var strBldr = new StringBuilder();
            strBldr.Append(this._mainfullQueryBldrWithoutPage);
            getQueryPageStatement(pageEntity,strBldr);
            getQueryEndStatement(strBldr);
            return strBldr.ToString();
        }
    }
}
