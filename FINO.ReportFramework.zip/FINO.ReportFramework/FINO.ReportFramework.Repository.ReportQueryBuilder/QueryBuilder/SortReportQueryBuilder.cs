﻿using FINO.CoreProject.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using FINO.ReportFramework.Repository.QueryBuilder;

namespace FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder
{
    public abstract partial class ReportQueryBuilderImpl : BaseRepositoryWithLoggerImpl, ReportQueryBuilder
    {
        //protected StringBuilder GetSortQuery()
    }
}
