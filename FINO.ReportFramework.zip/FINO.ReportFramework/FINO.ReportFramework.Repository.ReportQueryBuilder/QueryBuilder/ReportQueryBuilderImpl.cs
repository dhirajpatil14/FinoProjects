﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Repository.QueryBuilder;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder
{
    public abstract partial class ReportQueryBuilderImpl: BaseRepositoryWithLoggerImpl,ReportQueryBuilder
    {
        #region PrivateDeclaration
        private StringBuilder _declareStrBldr;
        private StringBuilder _fieldStrBldr;
        private StringBuilder _filterBldr;
        private StringBuilder _sortBldr;
        private StringBuilder _mainfullQueryStrBldr;
        private StringBuilder _maincountQueryStrBldr;
        private StringBuilder _mainfullQueryBldrWithoutPage;
        private String _fromClause;

        public QueryDataEntity QueryDataEntity { get; private set; }
        #endregion PrivateDeclaration

        #region QueryBuilders
        private SortQueryBuilder _sortQueryBuilder;
        private FieldQueryBuilder _fieldQueryBuilder;
        private FilterQueryBuilder _filterQueryBuilder;
        private PaginationQueryBuilder  _pageQueryBuilder;


        #endregion QueryBuilders

        protected override void Dispose(bool disposing)
        {
            if(this._sortBldr != null)
            {
                this._sortBldr.Clear();
                this._sortBldr = null;
            }
            if(this._sortQueryBuilder != null)
            {
                this._sortQueryBuilder.Dispose();
                this._sortQueryBuilder = null;
            }
            if(this._declareStrBldr != null)
            {
                this._declareStrBldr.Clear();
                this._declareStrBldr = null;
            }
            if(this._filterBldr != null)
            {
                this._filterBldr.Clear();
                this._filterBldr = null;
            }
            if(this._filterQueryBuilder != null)
            {
                this._filterQueryBuilder.Dispose();
                this._filterQueryBuilder = null;
            }
            if(this._fieldStrBldr != null)
            {
                this._fieldStrBldr.Clear();
                this._fieldStrBldr = null;
            }
            if(this._fieldQueryBuilder != null)
            {
                this._fieldQueryBuilder.Dispose();
                this._fieldQueryBuilder = null;
            }
            if(this._pageQueryBuilder != null)
            {
                this._pageQueryBuilder.Dispose();
                this._pageQueryBuilder = null;
            }

            if(this._maincountQueryStrBldr != null)
            {
                this._maincountQueryStrBldr.Clear();
                this._maincountQueryStrBldr = null;
            }

            if (this._mainfullQueryStrBldr != null)
            {
                this._mainfullQueryStrBldr.Clear();
                this._mainfullQueryStrBldr = null;
            }

            if (this._mainfullQueryBldrWithoutPage != null)
            {
                this._mainfullQueryBldrWithoutPage.Clear();
                this._mainfullQueryBldrWithoutPage = null;
            }


            base.Dispose(disposing);
        }

        public new dynamic New(ILogger logger, QueryDataEntity queryDataEntity)
        {
            base.New(logger);
             _sortBldr = new StringBuilder();
            _sortQueryBuilder = new SortQueryBuilder().New(logger, _sortBldr, queryDataEntity);

            _fieldStrBldr = new StringBuilder();
            _fieldQueryBuilder = new FieldQueryBuilder().New(logger, _fieldStrBldr, queryDataEntity);

            _filterBldr = new StringBuilder();
            _filterQueryBuilder = new FilterQueryBuilder().New(logger, _filterBldr, queryDataEntity);

            _pageQueryBuilder = new PaginationQueryBuilder().New(logger, null);

            return this;
        }
 
        public abstract String FromClause();

        public abstract String ? WhereClause();
    }
}
