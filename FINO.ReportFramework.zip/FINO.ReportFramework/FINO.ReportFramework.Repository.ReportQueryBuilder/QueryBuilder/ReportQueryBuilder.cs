﻿using FINO.CoreProject.Repository.Base;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Entities.Request;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder
{
    public interface ReportQueryBuilder : BaseRepositoryWithLogger
    {
        QueryDataEntity QueryDataEntity { get;}
        String GetCountQuery(FilterRequestWithHeader request);
        String GetFullQuery(FilterRequestWithHeader request);
        FilterRequestWithHeader GetFilterRequestWithHeader(FilterRequest request, HeaderEntity header);
        QueryEntity CreateQueryForExecution(FilterRequest request, HeaderEntity header);
        String ResetQueryForPage(PageEntity pageEntity);
        String FromClause();
        String? WhereClause();
        new dynamic New(ILogger logger, QueryDataEntity queryDataEntity);
    }
}
