﻿using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Field
{
    public  interface FieldDetail : DisplayFieldEntity 
    {
        SqlDbType dbType { get; set; }
        Int32 ? size { get; set; }
        String dbField { get; set; }
        String declareVariable { get; set; }
        Boolean mandatory { get; set; }

    }

    public class FieldDetailImpl : DisplayFieldEntityImpl , FieldDetail
    {
        public Int32 ? size { get; set;}
        public required SqlDbType dbType { get; set; }
        public required String dbField { get; set; }
        public required String declareVariable { get; set;}
        public Boolean mandatory { get; set; }  
    }

}
