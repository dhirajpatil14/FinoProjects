﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Field
{
    public interface DisplayFieldEntity : FieldEntity
    {
        String ? display { get; set; }
    }

    public class DisplayFieldEntityImpl : FieldEntityImpl , DisplayFieldEntity
    {
        public String ? display { get; set; }
    }
}
