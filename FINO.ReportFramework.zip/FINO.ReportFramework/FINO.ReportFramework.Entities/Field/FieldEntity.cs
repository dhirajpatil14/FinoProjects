﻿using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Field
{
    public interface FieldEntity : BaseEntity
    {
        string field { get; set; }
    }

    public class FieldEntityImpl : BaseEntityImpl, FieldEntity
    {
        public required string field { get; set; }
    }
}
