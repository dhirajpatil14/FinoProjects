﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Field;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Response
{
    public interface ReportFieldResponse : BaseEntity
    {
       IEnumerable<DisplayFieldEntity> fields { get; set; }
    }

    public class ReportFieldResponseImpl : BaseEntityImpl , ReportFieldResponse
    {
        public required IEnumerable<DisplayFieldEntity> fields { get; set; }
    }
}
