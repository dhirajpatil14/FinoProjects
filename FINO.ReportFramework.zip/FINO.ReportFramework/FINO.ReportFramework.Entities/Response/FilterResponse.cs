﻿using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Enums;

namespace FINO.ReportFramework.Entities.Response
{
    
    public interface FilterResponse : BaseEntity
    {
        Int64 TotalCount { get; set; }
        Int64 CurrentCount { get; set; }
        Int32 Page  { get; set; }
        dynamic ? Data { get; set; }
    }

    public class FilterResponseImpl : BaseEntityImpl , FilterResponse
    {
        public required Int64 TotalCount { get; set; }
        public required Int64 CurrentCount { get; set; }
        public required Int32 Page { get; set; }
        public dynamic ? Data { get; set; }
        public FilterResponseImpl() : base() { 
            this.TotalCount = 0;
            this.CurrentCount = 0;
            this.Page = 0;
            this.Data = null;
        }
    }

    public interface ReportResponse : BaseResponseEntity
    {
        FilterResponse ResponseData { get; set; }
    }

    public class ReportResponseImpl : BaseResponseEntityImpl, ReportResponse
    {
        public FilterResponse ResponseData { get; set; }
    }
}
