﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Filter;
using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Request
{
    public interface FilterRequest : BaseEntity
    {
        IList<FilterEntity> filters { get; set; }

        SortEntity? sort { get; set; }

        PageEntity? page { get; set; }
    }

    public class FilterRequestImpl : BaseEntityImpl, FilterRequest
    {
        public required IList<FilterEntity> filters { get; set; }

        public SortEntity? sort { get; set; }

        public PageEntity? page { get; set; }

    }
}
