﻿using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Request
{
    public interface ReportFieldRequest : BaseEntityWithUniqueId<Int32>
    {
        
    }

    public class ReportFieldRequestImpl : BaseEntityWithUniqueIdImpl<Int32> , ReportFieldRequest
    {
        
    }
}
