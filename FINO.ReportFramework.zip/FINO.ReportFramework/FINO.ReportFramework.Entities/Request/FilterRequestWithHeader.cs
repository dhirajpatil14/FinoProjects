﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Header;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Request
{
    public  interface FilterRequestWithHeader : BaseEntity
    {
        FilterRequest request { get; set; }
        HeaderEntity header { get; set; }
    }

    public class FilterRequestWithHeaderImpl : BaseEntityImpl, FilterRequestWithHeader
    {
        public required FilterRequest request { get; set; }
        public required HeaderEntity header { get; set; }
    }
}

