﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Query
{
    public  interface ReportEntity : BaseEntityWithUniqueId<Int64>,QueryEntity
    {
        String PackageFilePath { get; set; }
        String ExportFileName { get; set; }
        String ExportFilePath { get; set; }
        FileType FileType { get; set; }

        new ReportEntity New();
    }

    public class ReportEntityImpl : QueryEntityImpl, ReportEntity
    {
        public String PackageFilePath { get ; set ; }
        public string ExportFileName { get ; set ; }
        public string ExportFilePath { get ; set ; }
        public FileType FileType { get ; set ; }
        public long Id { get ; set ; }
        public new ReportEntity New()
        {
            return this;
        }
    }
}
