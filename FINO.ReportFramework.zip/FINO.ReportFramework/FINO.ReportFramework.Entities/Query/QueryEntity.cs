﻿using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Query
{
    public interface QueryEntity : BaseEntity
    {
        String CountQuery { get; set; }
        String FullQuery { get; set; }
    }

    public class QueryEntityImpl : BaseEntityImpl, QueryEntity
    {
        public required String  CountQuery { get; set;}
        public required String FullQuery { get; set;}
    }
}
