﻿using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Query
{
    public interface PageEntity : BaseEntity
    {
        int page { get; set; }
        int size { get; set; }
    }

    public class PageEntityImpl : BaseEntityImpl, PageEntity
    {
        public required int page { get; set; }
        public required int size { get; set; }
    }
}
