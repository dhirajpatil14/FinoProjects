﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Query
{
    public interface SortEntity : BaseEntity
    {
        IDictionary<string, SortType> sort { get; set; }
    }

    public class SortEntityImpl : BaseEntityImpl, SortEntity
    {
        public IDictionary<string, SortType> sort { get; set; }
    }
}
