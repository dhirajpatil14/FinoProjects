﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Enums;

namespace FINO.ReportFramework.Entities.Filter
{
    public interface FilterEntity : FieldEntity
    {
        OperatorType operatorType { get; set; }
        ConditionType condition { get; set; }
        dynamic value { get; set; }
    }
    
    public class FilterEntityImpl : FieldEntityImpl , FilterEntity
    {
        public required OperatorType operatorType { get ; set; }
        public required ConditionType condition { get ; set ; }
        public required dynamic value { get ; set; }
    }
}
