﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Filter;
using FINO.ReportFramework.Entities.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Header
{
    public interface HeaderEntity : BaseEntity
    {
        IList<String> fields { get; set; }
        IList<FilterEntity> ? filters { get; set; }

    }

    public class HeaderEntityImpl : BaseEntityImpl , HeaderEntity
    {
        public HeaderEntityImpl() {

           
        }
        public required IList<String> fields { get; set;}

        public IList<FilterEntity> ? filters { get; set; }
    }
}
