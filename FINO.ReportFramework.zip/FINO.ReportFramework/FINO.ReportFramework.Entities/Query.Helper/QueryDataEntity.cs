﻿using FINO.CoreProject.Entity.Base;
using FINO.ReportFramework.Entities.Field;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Entities.Query.Helper
{
    public interface QueryDataEntity:BaseEntity
    {
        IDictionary<String,FieldDetail> fields { get; set; }
    }

    public class QueryDataEntityImpl: BaseEntityImpl, QueryDataEntity
    {
        public required IDictionary<String,FieldDetail> fields {  set; get; }
    }
}
