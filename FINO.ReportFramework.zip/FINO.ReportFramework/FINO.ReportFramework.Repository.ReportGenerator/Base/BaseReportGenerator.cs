﻿using FINO.CoreProject.Repository.Base;
using Microsoft.Extensions.Logging;
using FINO.ReportFramework.Entities.Query;
namespace FINO.ReportFramework.Repository.ReportGenerator.Base
{
    public abstract class BaseReportGenerator : BaseRepositoryWithLoggerImpl
    {
        protected BaseReportGenerator() { }

        public abstract Task<Boolean> ExecutePackage(ReportEntity request);

        //protected Boolean Execute_Package(ReportEntity request)
        //{
        
        //}
    }
}
