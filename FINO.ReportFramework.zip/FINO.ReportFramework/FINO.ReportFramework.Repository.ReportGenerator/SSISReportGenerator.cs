﻿using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Repository.ReportGenerator.Base;
using Microsoft.Extensions.Logging;
using Microsoft.SqlServer.Dts.Runtime;

namespace FINO.ReportFramework.Repository.ReportGenerator
{
    public abstract class SSISReportGenerator : BaseReportGenerator
    {
        public SSISReportGenerator() { }
        public override async Task <Boolean> ExecutePackage(ReportEntity request)
        {
            Package package;
            Application app;
            try
            {
                app = new Application();
                package = app.LoadPackage(request.PackageFilePath, null);
                var vars = package.Variables;
                var pkgResult = package.Execute(null, vars, null, null, null);
                if (pkgResult == DTSExecResult.Success)
                {
                    return false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                package = null;
                app = null;
            }
        }

    }
}
