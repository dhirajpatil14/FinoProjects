﻿
using FINO.ReportFramework.Entities.Filter;
using FINO.ReportFramework.Entities.Header;
using FINO.ReportFramework.Entities.Query;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Enums;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Test.Repository.TestReport;
using Db4objects.Db4o;





var filters = new List<FilterEntity>();
filters.Add(
        new FilterEntityImpl
        {
            condition = FINO.ReportFramework.Enums.ConditionType.AND,
            field = "ProductCode",
            operatorType = FINO.ReportFramework.Enums.OperatorType.EQUALS,
            value = "ATMWD"
        });
filters.Add(
            new FilterEntityImpl
            {
                condition = FINO.ReportFramework.Enums.ConditionType.AND,
                field = "ResponseCode",
                operatorType = FINO.ReportFramework.Enums.OperatorType.NOT_EQUAL,
                value = 0
            });
filters.Add(
            new FilterEntityImpl
            {
                condition = FINO.ReportFramework.Enums.ConditionType.AND,
                field = "RequestDateTime",
                operatorType = FINO.ReportFramework.Enums.OperatorType.GREATER_THAN_EQUALS,
                value = "2020-02-20"
            });
filters.Add(
            new FilterEntityImpl
            {
                condition = FINO.ReportFramework.Enums.ConditionType.AND,
                field = "MessageString",
                operatorType = FINO.ReportFramework.Enums.OperatorType.ENDS_WITH,
                value = "Fail"
            });



var sorts = new Dictionary<string, SortType>();
sorts.Add("RequestId", SortType.Ascending);

var sortEntity = new SortEntityImpl
{
    sort = sorts,
};

var pageEntity = new PageEntityImpl { page = 1, size = 100 };

var filterRequest = new FilterRequestImpl
{
    filters = filters,
    sort = sortEntity,
    page = pageEntity
};



var header = new HeaderEntityImpl
{
    fields = filters.Select(f => f.field).ToList(),
};

using ILoggerFactory loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
ILogger logger = loggerFactory.CreateLogger<Program>();

var testRepo = new TestRepositoryImpl().New(logger);
//var queries=testRepo.GetQueries(filterRequest, header);
//Console.WriteLine(queries.CountQuery);
//Console.WriteLine(queries.FullQuery);

//pageEntity.page = 2;
//var resetpageQuery = testRepo.ResetQueryForPage(pageEntity);
//Console.WriteLine(resetpageQuery);

//queries = testRepo.GetQueries(filterRequest, header);
//Console.WriteLine(queries.CountQuery);
//Console.WriteLine(queries.FullQuery);

var fieldResponse = await testRepo.GetFieldList();

Console.WriteLine(fieldResponse);


//using (var db4odb = Db4oEmbedded.OpenFile("TestDb4oDatabase"))
//{
//    //
//    var obj = db4odb.Query<FilterRequest>();

//    if(obj == null)
//    {
//        db4odb.Store(filterRequest);
//        obj = new List<FilterRequest>();
//        obj.Add(filterRequest);

//    }
//    var evnt = new Db4objects.Db4o.Events.

//    var first = obj.FirstOrDefault().filters.FirstOrDefault();

//    Console.WriteLine(first);

//}


//String format = "{0}~{1}}";
//using (var lb = logger.BeginScope(format))
//{
//    logger.LogInformation("Hello World");
//}

//var testRepo = new TestRepository(logger);

//testRepo.GetTest();


