﻿using FINO.ReportFramework.Controller.Base;
using Microsoft.Extensions.Logging;
using Test.Repository.TestReport;

namespace TestController
{
    public class TestController : BaseReportController<TestRepository, TestReportQueryBuilder, TestReportFieldsData>
    {
        public TestController(TestRepository repository) : base(repository) { 
            var logger = new LoggerFactory().CreateLogger<TestController>();
            base.New(logger);
        }
    }
}
