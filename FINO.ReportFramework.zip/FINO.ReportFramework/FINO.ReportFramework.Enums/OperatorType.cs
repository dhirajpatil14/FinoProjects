﻿namespace FINO.ReportFramework.Enums
{
   public enum OperatorType
    {
        EQUALS = 0,
        NOT_EQUAL = 1,
        LESS_THAN = 2,
        GREATER_THAN = 3,
        LESS_THAN_EQUALS = 4,
        GREATER_THAN_EQUALS= 5,
        CONTAINS = 6,
        START_WITH = 7,
        ENDS_WITH = 8,
    }

}
