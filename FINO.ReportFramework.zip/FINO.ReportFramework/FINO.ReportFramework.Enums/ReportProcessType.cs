﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.ReportFramework.Enums
{
    public enum ReportProcessType
    {
        FRESH=0,
        PROCESSED_SUCCESSFULLY=1,
        INPROGRESS=2,
        FAILED=3,
        REPORT_GENERATED=4,
    }
}
