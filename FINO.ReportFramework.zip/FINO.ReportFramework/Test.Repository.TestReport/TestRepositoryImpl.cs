﻿using FINO.ReportFramework.Repository.ReportRepository.Base;
using Microsoft.Extensions.Logging;
using FINO.CoreProject.Repository.LogRepository;

using FINO.CoreProject.Repository.LogRepository.Implementation;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.ReportFramework.Entities.Response;
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.ReportFramework.Entities.Request;
using FINO.ReportFramework.Entities.Header;


namespace Test.Repository.TestReport
{
    public class TestRepositoryImpl : ReportRepositoryImpl<TestReportQueryBuilder,TestReportFieldsData>,TestRepository
    {
        private FINOLogger finoLogger;
        public TestRepositoryImpl()  {
        
        }

       public new dynamic New(ILogger logger)
        {
            base.New(logger: logger
                , new TestReportFieldsDataImpl()
                , new TestReportQueryBuilderImpl());
            return this;
        }

        public override async Task<Response<ReportResponse>> ExecuteReport(RequestWithRequestId<FilterRequest> request, HeaderEntity header)
        {
            return null;
        }

        public override async Task<Response<ReportFieldResponse>> GetReportFields(RequestWithRequestId<string> request)
        {
            var responseData = await this.GetFieldList();

            var response = new ResponseImpl<ReportFieldResponse>(respBody: responseData,corelationId:request.CorelationId,requestId:request.Id,responseCodes: FINO.CoreProject.Enums.ResponseCodes.Successful);
            return response;
        }

        public void GetTest()
        {
            //var finoLogger=new FINOLogger().New(this)
            //this.finoLogger.LOG(loglevel: LogLevel.Error, type: ReqRespType.Request, message: "Hello World");
            //return LogFormatter.GetFormattedString(new FullLogEntityImpl { CorelationId = "corel", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now, Description = "Desc1", ResponseCode = -1, Message = "Msg Test1", LogObject = "[{}]" });
        }


    }
}
