﻿using FINO.ReportFramework.Entities.Field;
using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Repository.ReportRepository.Base;

namespace Test.Repository.TestReport
{
    public class TestReportFieldsDataImpl : ReportDataDetailsImpl,TestReportFieldsData
    {
        //public new dynamic New()
        //{
        //    base.New();
        //    return this;
        //}
        public override QueryDataEntity ReportFieldsDefination()
        {
            IDictionary<String, FieldDetail> datas = new Dictionary<String, FieldDetail>();

            datas.Add("RequestId", new FieldDetailImpl
            {
                field = "RequestId",
                dbField = "req.RequestId",
                dbType = System.Data.SqlDbType.BigInt,
                display = "RequestId",
                declareVariable = "@requestId",
                size = 0
            });

            datas.Add("ClientId", new FieldDetailImpl
            {
                field = "ClientId",
                dbField = "req.ClientId",
                dbType = System.Data.SqlDbType.BigInt,
                size = 100,
                display = "Client Id",
                declareVariable = "@clientid"
            });

            datas.Add("ProductCode", new FieldDetailImpl
            {
                field = "ProductCode",
                dbField = "req.ProductCode",
                dbType = System.Data.SqlDbType.VarChar,
                size = 20,
                display = "Product Code",
                declareVariable = "@productcode"
            });
            datas.Add("Amount", new FieldDetailImpl
            {
                field = "Amount",
                dbField = "req.Amount",
                dbType = System.Data.SqlDbType.Money,
                size = 0,
                display = "Amount",
                declareVariable = "@amt"
            });

            datas.Add("RequestDateTime", new FieldDetailImpl
            {
                field = "RequestDateTime",
                dbField = "req.ReqDateTime",
                dbType = System.Data.SqlDbType.DateTime,
                display = "Reqest Date",
                declareVariable = "@reqDate"
            });

            datas.Add("Channel", new FieldDetailImpl
            {
                field = "Channel",
                dbField = "req.channelId",
                dbType = System.Data.SqlDbType.Int,
                display = "Channel",
                declareVariable = "@channelid"
            });

            datas.Add("ResponseId", new FieldDetailImpl
            {
                field = "ResponseId",
                dbField = "res.ResponseId",
                dbType = System.Data.SqlDbType.BigInt,
                display = "ResponseId",
                declareVariable = "@resId",
                size = 0
            });

            datas.Add("ResponseCode", new FieldDetailImpl
            {
                field = "ResponseCode",
                dbField = "res.ResponseCode",
                dbType = System.Data.SqlDbType.Int,
                display = "ResponseCode",
                declareVariable = "@rescode",
                size = 0
            });

            datas.Add("MessageString", new FieldDetailImpl
            {
                field = "MessageString",
                dbField = "res.MessageString",
                dbType = System.Data.SqlDbType.VarChar,
                size = 200,
                display = "Message",
                declareVariable = "@msgstr"
            });

            datas.Add("DisplayMessage", new FieldDetailImpl
            {
                field = "DisplayMessage",
                dbField = "res.DisplayMessage",
                dbType = System.Data.SqlDbType.VarChar,
                size = 200,
                display = "Display Message",
                declareVariable = "@displymsgstr"
            });
            return new QueryDataEntityImpl
            {
                fields = datas,
            };
        }
    }
}
