﻿using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Repository.TestReport
{
    public interface TestReportQueryBuilder : ReportQueryBuilder
    {
    }
}
