﻿using FINO.ReportFramework.Entities.Query.Helper;
using FINO.ReportFramework.Repository;
using FINO.ReportFramework.Repository.ReportQueryBuilder.QueryBuilder;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Repository.TestReport
{
    public class TestReportQueryBuilderImpl : ReportQueryBuilderImpl,TestReportQueryBuilder
    {
        public TestReportQueryBuilderImpl() : base() { }

        public override string FromClause()
        {
            return "TxnAepsPGPaymentRequest req inner join TxnAepsPGPaymentResponse res "
               + " on req.requestid=res.requestid ";
        }

        public override string WhereClause()
        {
            return " 1=1 ";
        }

        //public new dynamic New(ILogger logger, QueryDataEntity queryDataEntity)
        //{
        //    base.New(logger, queryDataEntity);
        //    return this;
        //}
    }
}
