﻿using FINO.ReportFramework.Repository.ReportRepository.Base;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.Repository.TestReport
{
    public interface TestRepository : ReportRepository<TestReportQueryBuilder, TestReportFieldsData>
    {
        new dynamic New(ILogger logger);
    }
}
