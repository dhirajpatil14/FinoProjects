﻿using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.OpenApi.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using FINO.CoreProject.Enums;
namespace FINO.CoreProject.RestService.Setup.Startup
{
    public abstract class Startup :IStartupConfiguration
    {
        public IConfiguration Configuration { get; }

        public IStartupConfiguration startupConfiguration { get; } 
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            startupConfiguration = new DefaultStartupConfiguration(configuration:configuration);
        }

        public Startup(IConfiguration configuration , IStartupConfiguration startupconfiguration)
        {
            Configuration = configuration;
            startupConfiguration = startupconfiguration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.

        public void ConfigureServices(IServiceCollection services)
        {
            startupConfiguration.ConfigureServices(services);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            startupConfiguration.Configure(app, env);
        } 

        // This method gets called by the runtime. Use this method to add services to the container.

    }
}
