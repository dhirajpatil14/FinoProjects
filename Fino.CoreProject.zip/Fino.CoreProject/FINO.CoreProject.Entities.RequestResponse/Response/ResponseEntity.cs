﻿using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Entity.RequestResponse.Common;
using FINO.CoreProject.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.RequestResponse.Response
{

    public interface ResponseMessageEntity : BaseEntity
    {
        String Msg { get; set; }
        String DispMsg { get; set; }

    }
    public interface BaseResponseEntity : ResponseMessageEntity
    {
        Int32 RespCode { get; set; }
    }

    public class ResponseMessageEntityImpl : BaseEntityImpl, ResponseMessageEntity
    {
        public String Msg { get; set; }
        public String DispMsg { get; set; }

    }
    public class BaseResponseEntityImpl : ResponseMessageEntityImpl, BaseResponseEntity
    {
        public Int32 RespCode { get; set; }
    }
   
   
    public interface Response<TResponseBody> : CorelationEntityWithUniqueId , BaseResponseEntity
    {
        DateTime RespDate { get; set; }
        TResponseBody RespBody { get; set; }
    }

    public class ResponseImpl<TResponseBody> : BaseResponseEntityImpl, Response<TResponseBody>
    {
        public DateTime RespDate { get; set; }
        public TResponseBody RespBody { get; set; }
        public String CorelationId { get ; set ; }
        public Int64 Id { get ; set ; }

        public ResponseImpl()
        {
            RespDate = DateTime.Now;
        }
        public ResponseImpl(TResponseBody respBody, String corelationId, Int64 requestId,ResponseCodes responseCodes ,String ? message =null,String ? displaymessage = null)
        {
            RespDate = DateTime.Now;
            RespBody = respBody;
            CorelationId = corelationId;
            Id = requestId;
            SetResponse(responseCodes , message, displaymessage);
        }

        public void SetResponse(ResponseCodes responseCodes,String ? message =null,String ? displaymessage=null)
        {
            this.RespCode= (Int32)responseCodes;
            this.RespDate = DateTime.Now;
            if(String.IsNullOrEmpty(message))
            {
                this.Msg= responseCodes.ToString();
            }
            else
            {
                this.Msg = message;
            }

            if (String.IsNullOrEmpty(displaymessage))
            {
                this.DispMsg= responseCodes.ToString();
            }
            else
            {
                this.DispMsg = displaymessage;
            }
        }
    }
}
