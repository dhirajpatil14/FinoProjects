﻿using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.RequestResponse.Common
{
    public interface CorelationEntity : BaseEntity
    {
        String CorelationId { get; set; }
    }

    public class CorelationEntityImpl : BaseEntityImpl, CorelationEntity
    {
        public required string CorelationId { get; set; }
    }

    public interface CorelationEntityWithUniqueId : CorelationEntity , BaseEntityWithUniqueId<Int64> { }

    public class CorelationEntityWithUniqueIdImpl : BaseEntityWithUniqueIdImpl<Int64>, CorelationEntityWithUniqueId
    {
        public required string CorelationId { get; set; }
    }
}
