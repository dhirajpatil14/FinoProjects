﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Entity.RequestResponse.Common;

namespace FINO.CoreProject.Entity.RequestResponse.Request
{

    public interface Request<TRequestBody>: CorelationEntity 
    {
        DateTime ReqDate { get; set; }
        Int32 methodId { get; set; }
        TRequestBody ReqBody { get; set; }
    }

    public class RequestImpl<TRequestBody> : CorelationEntityImpl, Request<TRequestBody>
    {
        public required DateTime ReqDate { get; set; }
        public required Int32 methodId { get; set; }
        public required TRequestBody ReqBody { get; set; }

    }

    public interface RequestWithRequestId <TRequestBody> : Request<TRequestBody>, BaseEntityWithUniqueId<Int64>
    {
        
    }

    public class RequestWithRequestIdImpl<TRequestBody> : RequestImpl<TRequestBody>, RequestWithRequestId<TRequestBody>
    {
        public Int64 Id { get ; set ; }
    }
}
