﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging.Abstractions;
using System.Diagnostics;
namespace FINO.CoreProject.Repository.LogRepository.Formatter
{
    internal static partial class LogFormatter
    {
        private const string LOGFORMAT = "{0}[{1}]:{3}~{4}~{5}~{6}~{7}~{8}({2})~{9}~{10}~{11}~{12}~{13}";
        private const string LOGFORMATWITHASSEMBLY= "{0}[{1}]:{3}~{4}~{5}~{6}~{14}~{7}~{8}({2})~{9}~{10}~{11}~{12}~{13}";
                                                                                                                       
        /*
             * LogTimeStamp-{0}
             * [LogLevel]-{1}
             * (LineNo):-{2}
             * TimeStamp-{3}
             * ~SessionId-{4}
             * ~CorelationId-{5}
             * ~Tag/Node-{6}
             * ~SourceClass-{7}
             * ~Method-{8}
             * ~Type(Req/Resp)-{9}
             * ~ResposeCode-{10}
             * ~Description-{11}
             * ~Message-{12}
             * ~LogObject-{13}
             * ~AssemblyInfo-{14}
         */

        private const string DATETIMEFORMAT = "yyyy-MM-dd HH:mm:ss.fffff";

        private static SourceEntity getCallerDetails()
        {
            var stack = new StackFrame(7, true);
            var methodinfo = stack.GetMethod();
            var classname = methodinfo.ReflectedType;
            var assembly = classname.Assembly;
            return new SourceEntityImpl
            {
                LineNo = stack.GetFileLineNumber(),
                SourceAssembly = assembly.FullName,
                SourceClass = classname.FullName,
                SourceMethod = methodinfo.Name
            };
        }
        private static string getFormattedString(
            LogLevel loglevel
            , DateTime sysdatetime
            , string sessionid
            , string corelationid
            , string servernode
            , ReqRespType reqresptype
            , int? responsecode
            , string? description
            , string? message
            , string? logobject
            )
        {
            var sourceInfo = getCallerDetails();

            return string.Format(LOGFORMAT
                                , DateTime.Now.ToString(DATETIMEFORMAT)
                                , loglevel
                                , sourceInfo.LineNo
                                , sysdatetime.ToString(DATETIMEFORMAT)
                                , sessionid
                                , corelationid
                                , servernode
                                , sourceInfo.SourceClass
                                , sourceInfo.SourceMethod
                                , reqresptype
                                , responsecode
                                , description
                                , message
                                , logobject
                                );
        }

        private static string getFormattedStringWithAssemblyInfo(
            LogLevel loglevel
            , DateTime sysdatetime
            , string sessionid
            , string corelationid
            , string servernode
            , ReqRespType reqresptype
            , int? responsecode
            , string? description
            , string? message
            , string? logobject
            )
        {
            var sourceInfo = getCallerDetails();

            return string.Format(LOGFORMATWITHASSEMBLY
                                , DateTime.Now.ToString(DATETIMEFORMAT)
                                , loglevel
                                , sourceInfo.LineNo
                                , sysdatetime.ToString(DATETIMEFORMAT)
                                , sessionid
                                , corelationid
                                , servernode
                                , sourceInfo.SourceClass
                                , sourceInfo.SourceMethod
                                , reqresptype
                                , responsecode
                                , description
                                , message
                                , logobject
                                , sourceInfo.SourceAssembly
                                );
        }

        internal static string GetFormattedString(LogEntity logEntity,Boolean withassembly=false)
        {
            if (withassembly)
            {
                return getFormattedStringWithAssemblyInfo(
                  loglevel: logEntity.LogLevel
                , sysdatetime: logEntity.SysDateTime
                , sessionid: logEntity.SessionId
                , corelationid: logEntity.CorelationId
                , servernode: logEntity.ServerNode
                , reqresptype: logEntity.ReqRespType
                , responsecode: null
                , description: null
                , message: null
                , logobject: null
                );
            }
            else
            {
                return getFormattedString(
                          loglevel: logEntity.LogLevel
                        , sysdatetime: logEntity.SysDateTime
                        , sessionid: logEntity.SessionId
                        , corelationid: logEntity.CorelationId
                        , servernode: logEntity.ServerNode
                        , reqresptype: logEntity.ReqRespType
                        , responsecode: null
                        , description: null
                        , message: null
                        , logobject: null
                        );
            }
        }
    }
}
