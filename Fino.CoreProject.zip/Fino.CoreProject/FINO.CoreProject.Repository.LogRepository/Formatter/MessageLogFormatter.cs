﻿using FINO.CoreProject.Entity.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Formatter
{
    internal static partial class LogFormatter
    {
        internal static string GetFormattedString(MessageLogEntity logEntity)
        {
            return getFormattedString(
                      loglevel: logEntity.LogLevel
                    , sysdatetime: logEntity.SysDateTime
                    , sessionid: logEntity.SessionId
                    , corelationid: logEntity.CorelationId
                    , servernode: logEntity.ServerNode
                    , reqresptype: logEntity.ReqRespType
                    , responsecode: null
                    , description: null
                    , message: logEntity.Message
                    , logobject: null
                    );
        }
    }
}
