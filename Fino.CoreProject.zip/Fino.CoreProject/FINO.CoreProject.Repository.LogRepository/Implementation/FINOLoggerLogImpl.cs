﻿using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public partial class FINOLogger : FINOLoggerLog
    {
        public async Task Log(LogLevel Loglevel, ReqRespType type, string message)
        {
           await this.logTask(loglevel: Loglevel,
                message: this.getFormattedString(level: Loglevel, 
                type: type, 
                message: message));
        }

        public async Task Log<T>(LogLevel Loglevel, ReqRespType type, string message, T obj)
        {
            await this.logTask(loglevel: Loglevel,
            message: this.getFormattedString<T>(level: Loglevel, 
            type: type, 
            message: message,
            obj:obj));
        }

        public async Task Log(LogLevel Loglevel, ReqRespType type, int responseCode, string description, string message)
        {
            await this.logTask(loglevel: Loglevel,
            message: this.getFormattedString(level: Loglevel, 
            type: type, 
            message: message,
            responseCode:responseCode,
            description:description));
        }

        public async Task Log<T>(LogLevel Loglevel, ReqRespType type, int responseCode, string description, string message, T obj)
        {
            await this.logTask(loglevel: Loglevel, 
                message: this.getFormattedString<T>(level: Loglevel, 
                type: type, 
                message: message, 
                obj: obj, 
                responseCode: responseCode, 
                description: description));
        }
    }
}
