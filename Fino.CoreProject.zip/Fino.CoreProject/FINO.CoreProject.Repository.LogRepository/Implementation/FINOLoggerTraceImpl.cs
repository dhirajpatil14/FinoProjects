﻿using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public partial class FINOLogger : FINOLoggerTrace
    {
        public async Task LogTrace(ReqRespType type, string message)
        {
           await this.logTask(loglevel: LogLevel.Trace,
                message: this.getFormattedString(level: LogLevel.Trace, 
                type: type, 
                message: message));
        }

        public async Task LogTrace<T>(ReqRespType type, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Trace,
            message: this.getFormattedString<T>(level: LogLevel.Trace, 
            type: type, 
            message: message,
            obj:obj));
        }

        public async Task LogTrace(ReqRespType type, int responseCode, string description, string message)
        {
            await this.logTask(loglevel: LogLevel.Trace,
            message: this.getFormattedString(level: LogLevel.Trace, 
            type: type, 
            message: message,
            responseCode:responseCode,
            description:description));
        }

        public async Task LogTrace<T>(ReqRespType type, int responseCode, string description, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Trace, 
                message: this.getFormattedString<T>(level: LogLevel.Trace, 
                type: type, 
                message: message, 
                obj: obj, 
                responseCode: responseCode, 
                description: description));
        }
    }
}
