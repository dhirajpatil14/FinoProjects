﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Entity.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public interface FINOLoggerLog
    {
        Task Log(LogLevel Loglevel, ReqRespType type, string message);
        Task Log<T>(LogLevel Loglevel, ReqRespType type, string message, T obj);
        Task Log(LogLevel Loglevel, ReqRespType type, int responseCode, string description, string message);
        Task Log<T>(LogLevel Loglevel, ReqRespType type, int responseCode, string description, string message, T obj);
    }
}
