﻿using FINO.CoreProject.Entity.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public  interface FINOLoggerTrace
    {
        Task LogTrace(ReqRespType type, string message);
        Task LogTrace<T>(ReqRespType type, string message, T obj);
        Task LogTrace(ReqRespType type, int responseCode, string description, string message);
        Task LogTrace<T>(ReqRespType type, int responseCode, string description, string message, T obj);

    }
}
