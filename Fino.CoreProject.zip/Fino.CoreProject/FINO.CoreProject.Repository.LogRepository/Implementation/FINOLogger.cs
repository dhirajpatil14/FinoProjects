﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Entity.Logger;
using FINO.CoreProject.Repository.LogRepository.Formatter;
using System.Runtime.CompilerServices;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public partial class FINOLogger : FINOLoggerBaseImpl
    {
        public new FINOLogger New(ILogger logger, string corelationId, string sessionid, string servernode)
        {
            base.New(logger:logger, corelationId: corelationId, sessionid: sessionid, servernode: servernode);
            return this;
        }
        private string getFormattedString(LogLevel level, ReqRespType type, string message)
        {
            return LogFormatter.GetFormattedString(new MessageLogEntityImpl
            {
                CorelationId = CorelationId,
                SessionId = SessionId,
                ServerNode = ServerNode,
                LogLevel = level,
                ReqRespType = type,
                Message = message,
                SysDateTime = DateTime.Now,
            });
        }

        private string getFormattedString<T>(LogLevel level, ReqRespType type, string message, T obj)
        {
            return LogFormatter.GetFormattedString(new ObjectLogEntityImpl
            {
                CorelationId = CorelationId,
                SessionId = SessionId,
                ServerNode = ServerNode,
                LogLevel = level,
                ReqRespType = type,
                Message = message,
                SysDateTime = DateTime.Now,
                LogObject = obj.ToString()
            });
        }

        private string getFormattedString(LogLevel level, ReqRespType type, int responseCode, string description, string message)
        {
            return LogFormatter.GetFormattedString(new DetailLogEntityWithMessageImpl
            {
                CorelationId = CorelationId,
                SessionId = SessionId,
                ServerNode = ServerNode,
                LogLevel = level,
                ReqRespType = type,
                Message = message,
                SysDateTime = DateTime.Now,
                Description = description,
                ResponseCode = responseCode
            });
        }

        private string getFormattedString<T>(LogLevel level, ReqRespType type, int responseCode, string description, string message, T obj)
        {
            return LogFormatter.GetFormattedString(new FullLogEntityImpl
            {
                CorelationId = CorelationId,
                SessionId = SessionId,
                ServerNode = ServerNode,
                LogLevel = level,
                ReqRespType = type,
                Message = message,
                SysDateTime = DateTime.Now,
                LogObject = obj.ToString(),
                Description = description,
                ResponseCode = responseCode
            });
        }

        private async Task logTask(LogLevel loglevel,String message) {
            await Task.Run(() => {
                this.Logger.Log(
                logLevel: LogLevel.Information
                , message: message);
            });
        }
    }

}
