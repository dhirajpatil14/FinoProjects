﻿using FINO.CoreProject.Entity.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public  interface FINOLoggerWarning
    {
        Task LogWarning(ReqRespType type, string message);
        Task LogWarning<T>(ReqRespType type, string message, T obj);
        Task LogWarning(ReqRespType type, int responseCode, string description, string message);
        Task LogWarning<T>(ReqRespType type, int responseCode, string description, string message, T obj);
    }
}
