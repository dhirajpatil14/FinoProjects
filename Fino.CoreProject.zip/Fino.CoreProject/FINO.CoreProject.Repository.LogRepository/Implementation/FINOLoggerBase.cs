﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public interface FINOLoggerBase : IDisposable
    {
        ILogger Logger { get; }
        string CorelationId { get; }
        string SessionId { get; }
        string ServerNode { get; }
        FINOLoggerBase New(ILogger logger, string corelationId, string sessionid, string servernode);
    }

    public abstract class FINOLoggerBaseImpl : FINOLoggerBase
    {
        public ILogger Logger { get; private set; }
        public string CorelationId { get; private set; }

        public string SessionId { get; private set; }

        public string ServerNode { get; private set; }

        public FINOLoggerBase New(ILogger logger, string corelationId, string sessionid, string servernode)
        {
            Logger = logger;
            CorelationId = corelationId;
            SessionId = sessionid;
            ServerNode = servernode;
            return this;
        }
        public void Dispose()
        {
            if (Logger != null) { Logger = null; }
        }
    }
}
