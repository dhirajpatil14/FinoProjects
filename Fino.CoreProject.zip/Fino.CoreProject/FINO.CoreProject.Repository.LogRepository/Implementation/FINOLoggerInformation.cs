﻿using FINO.CoreProject.Entity.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public  interface FINOLoggerInformation
    {
        Task LogInformation(ReqRespType type, string message);
        Task LogInformation<T>(ReqRespType type, string message, T obj);
        Task LogInformation(ReqRespType type, int responseCode, string description, string message);
        Task LogInformation<T>(ReqRespType type, int responseCode, string description, string message, T obj);

    }
}
