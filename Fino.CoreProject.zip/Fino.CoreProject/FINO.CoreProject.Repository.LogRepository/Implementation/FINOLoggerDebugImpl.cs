﻿using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public partial class FINOLogger : FINOLoggerDebug
    {
        public async Task LogDebug(ReqRespType type, string message)
        {
           await this.logTask(loglevel: LogLevel.Debug,
                message: this.getFormattedString(level: LogLevel.Debug, 
                type: type, 
                message: message));
        }

        public async Task LogDebug<T>(ReqRespType type, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Debug,
            message: this.getFormattedString<T>(level: LogLevel.Debug, 
            type: type, 
            message: message,
            obj:obj));
        }

        public async Task LogDebug(ReqRespType type, int responseCode, string description, string message)
        {
            await this.logTask(loglevel: LogLevel.Debug,
            message: this.getFormattedString(level: LogLevel.Debug, 
            type: type, 
            message: message,
            responseCode:responseCode,
            description:description));
        }

        public async Task LogDebug<T>(ReqRespType type, int responseCode, string description, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Debug, 
                message: this.getFormattedString<T>(level: LogLevel.Debug, 
                type: type, 
                message: message, 
                obj: obj, 
                responseCode: responseCode, 
                description: description));
        }
    }
}
