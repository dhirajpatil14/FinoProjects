﻿using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.LogRepository.Implementation
{
    public partial class FINOLogger : FINOLoggerCritical
    {
        public async Task LogCritical(ReqRespType type, string message)
        {
           await this.logTask(loglevel: LogLevel.Critical,
                message: this.getFormattedString(level: LogLevel.Critical, 
                type: type, 
                message: message));
        }

        public async Task LogCritical<T>(ReqRespType type, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Critical,
            message: this.getFormattedString<T>(level: LogLevel.Critical, 
            type: type, 
            message: message,
            obj:obj));
        }

        public async Task LogCritical(ReqRespType type, int responseCode, string description, string message)
        {
            await this.logTask(loglevel: LogLevel.Critical,
            message: this.getFormattedString(level: LogLevel.Critical, 
            type: type, 
            message: message,
            responseCode:responseCode,
            description:description));
        }

        public async Task LogCritical<T>(ReqRespType type, int responseCode, string description, string message, T obj)
        {
            await this.logTask(loglevel: LogLevel.Critical, 
                message: this.getFormattedString<T>(level: LogLevel.Critical, 
                type: type, 
                message: message, 
                obj: obj, 
                responseCode: responseCode, 
                description: description));
        }
    }
}
