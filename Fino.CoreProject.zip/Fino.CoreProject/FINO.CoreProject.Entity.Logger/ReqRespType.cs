﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Logger
{
    public enum ReqRespType
    {
        Request = 0,
        Response = 1,
        Error = 2
    }
}
