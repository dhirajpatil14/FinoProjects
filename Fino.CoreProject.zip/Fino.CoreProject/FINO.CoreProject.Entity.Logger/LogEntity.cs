﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Logger
{
    public interface SourceEntity
    {
        String SourceAssembly { get; set; }
        String SourceClass { get; set; }
        String SourceMethod { get; set; }
        Int32 LineNo { get; set; }

    }

    public interface LogEntity
    {
        DateTime SysDateTime { get; set; }
        LogLevel LogLevel { get; set; }
        String SessionId { get; set; }   
        String CorelationId { get; set; }
        String ServerNode { get; set; }
        ReqRespType ReqRespType { get; set; }
    }

    public interface DetailLogEntity : LogEntity
    {
        Int32 ResponseCode { get; set; }
        String Description { get; set; }
    }

    public interface MessageLogEntity : LogEntity
    {
        String Message { get; set; }
    }

    public interface DetailLogEntityWithMessage : DetailLogEntity , MessageLogEntity
    {

    }

    public interface ObjectLogEntity: MessageLogEntity
    {
        String LogObject { get; set; }
    }

    public interface FullLogEntity : DetailLogEntity, ObjectLogEntity 
    {

    }
}
