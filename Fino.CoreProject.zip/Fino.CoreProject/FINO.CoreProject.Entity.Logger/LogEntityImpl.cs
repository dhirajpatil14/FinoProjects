﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Logger
{

    public class SourceEntityImpl : SourceEntity
    {
        public String SourceAssembly { get; set; }
        public String SourceClass { get; set; }

        public String SourceMethod { get; set; }
        public Int32 LineNo { get; set; }
    }

    public class LogEntityImpl : LogEntity
    {
        public DateTime SysDateTime { get; set; }
        public LogLevel LogLevel { get; set; }
        public String SessionId { get; set; }

        public String CorelationId { get; set; }

        public String ServerNode { get; set; }

        public ReqRespType ReqRespType { get; set; }

    }

    public class DetailLogEntityImpl : LogEntityImpl, DetailLogEntity
    {
        public Int32 ResponseCode { get; set; }
        public String Description { get; set; }
    }

    public class MessageLogEntityImpl : LogEntityImpl, MessageLogEntity
    {
        public String Message { get; set; }
    }

    public class ObjectLogEntityImpl : MessageLogEntityImpl, ObjectLogEntity
    {
        public String LogObject { get; set; }
    }

    public class DetailLogEntityWithMessageImpl : DetailLogEntityImpl, DetailLogEntityWithMessage
    {
        public String Message { get; set; }
    }

    public class FullLogEntityImpl : DetailLogEntityImpl, FullLogEntity
    {
        public String LogObject { get; set; }
        public String Message { get; set; }
    }
}
