﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Repository.ControllerRepository;
using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.CoreProject.Entity.RequestResponse.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Net;


namespace FINO.CoreProject.BaseController
{
    public abstract class BaseMasterController<TRepository,TModel,TId> : BaseController<TRepository>
        where TRepository : BaseRepositoryWithMaster<TModel,TId>
        where TModel : BaseEntityForMaster<TId>
    {
        protected BaseMasterController(TRepository repository) : base(repository) { }

        protected new BaseMasterController<TRepository,TModel,TId> New (ILogger logger)
        {
           base.New(logger);
            return this;
        }

        [HttpPost]
        [Route("get")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public virtual async Task<ActionResult<Response<TModel>>> Get([FromBody] Request<TId> request)
        {
            this._logger.LogInformation("Request received for {0}", request);
            try
            {
                var result = await this._repository.Get(request);
                this._logger.LogInformation("Response received {0}", result.RespCode);
                this._logger.LogDebug("Response received {0}", result);
                return Ok(result);
            }
            catch (Exception ex)
            {
                this._logger.LogError(ex, "Exception");
                var response=  new ResponseImpl<TModel> { Id = 0, Msg = "", DispMsg = "", CorelationId = "", RespBody = default(TModel), RespDate = DateTime.Now };
                // return StatusCode(this.getErrorResponseCode(HttpStatusCode.InternalServerError),response);
                return null;
            }
            finally
            {

            }

        }

        [HttpGet]
        [Route("getAll")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<Response<IEnumerable<TModel>>>> GetAll()
        {
             return Ok(await this._repository.GetAll());
        }

        [HttpPost]
        [Route("Save")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public virtual async Task<ActionResult<Response<TModel>>> Save([FromBody] Request<TModel> request)
        {
            return Ok(await this._repository.Save(request));
        }

        [HttpPost]
        [Route("Update")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public virtual async Task<ActionResult<Response<TModel>>> Update([FromBody] Request<TModel> request)
        {
            return Ok(await this._repository.Update(request));
        }

        [HttpPost]
        [Route("Delete")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public virtual async Task<ActionResult<Response<Boolean>>> Delete([FromBody] Request<TId> request)
        {
            return Ok( await this._repository.Delete(request));
        }
    }
}
