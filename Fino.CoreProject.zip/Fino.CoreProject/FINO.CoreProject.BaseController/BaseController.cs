﻿
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Repository.Base;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net;
namespace FINO.CoreProject.BaseController
{
    [Route("api/[controller]")]
    [ApiController]
    [RequireHttps]
    public abstract class BaseController<TRepository> : ControllerBase , IDisposable
        where TRepository : BaseRepositoryWithLogger
    {
        public ILogger _logger { get; private set; }
        private bool _disposedValue;
        protected TRepository _repository { get; private set; }
        public BaseController(TRepository repository)
        {
            this._repository = repository;
        }
        protected BaseController<TRepository> New(ILogger logger)
        {
            this._logger = logger;
            return this;
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    if (this._logger != null)
                    {
                        this._logger = null;
                    }
                    if (this._repository != null)
                    {
                        this._repository.Dispose();
                    }
                    // TODO: dispose managed state (managed objects)
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        //protected Int32 getErrorResponseCode(HttpStatusCode statusCode)
        //{
        //    Int32 errorCode=0;
        //    switch (statusCode)
        //    {
        //        case HttpStatusCode.InternalServerError:
        //            {
        //                errorCode = ((Int32) statusCode + 4);
        //                break;
        //            }
        //        default:
        //            {
        //                errorCode = (Int32)statusCode;
        //                break;
        //            }
        //    }
        //    return errorCode;
        //}

        //protected ActionResult<Response<TResponseBody>> getResponseForError<TRequestBody, TResponseBody>(RequestWithRequestId<TRequestBody> request, HttpStatusCode statusCode , String ? message) {
        //    var response = new ResponseImpl<TResponseBody> { CorelationId = request.CorelationId, Id = request.Id, DispMsg = "Error", Msg = message, RespCode = -2, RespDate = DateTime.Now, RespBody = default(TResponseBody) };
        //    return StatusCode(getErrorResponseCode(statusCode),response);
        //}
    }
}
