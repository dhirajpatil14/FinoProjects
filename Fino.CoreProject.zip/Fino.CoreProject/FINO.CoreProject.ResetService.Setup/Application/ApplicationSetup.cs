﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.ResetService.Setup.Application
{
    public abstract class ApplicationSetup
    {
        [Description("get Webapplication")]
        protected static WebApplication App { get { return AppInitialization.App; } }

        [Description("Setup WebApplication Initialization")]
        public static WebApplication Initialize(WebApplication app) => AppInitialization.App = app;
    }
}
