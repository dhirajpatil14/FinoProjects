﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using System.Runtime.CompilerServices;

namespace FINO.CoreProject.ResetService.Setup.Application
{
    public partial class SetupApplication :ApplicationSetup
    {
        public static WebApplication setupDevEnvironment() {
            if (App.Environment.IsDevelopment())
            {
                App.UseSwagger();
                App.UseSwaggerUI();
            }
            return App;
        }

        public static WebApplication useHttpsRedirection()
        {
            App.UseHttpsRedirection();
            return App;
        }
    }
}
