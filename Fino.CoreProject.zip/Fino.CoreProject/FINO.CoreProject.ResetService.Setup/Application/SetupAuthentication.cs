﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.ResetService.Setup.Application
{
    public partial class SetupApplication : ApplicationSetup
    {
        public static WebApplication useAuthentication()
        {
            App.UseAuthentication();
            return App;
        }
    }


}
