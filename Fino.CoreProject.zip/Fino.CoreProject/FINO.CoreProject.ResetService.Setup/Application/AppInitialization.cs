﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.ResetService.Setup.Application
{
    public static class AppInitialization
    {
        private static WebApplication _app;
        [Description("Static Web Application get and set")]
        public static WebApplication App {
            get { return _app; }
            set { 
                if(_app ==null  ) _app = value; 
            }
        }
    }
}
