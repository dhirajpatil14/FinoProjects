﻿using FINO.CoreProject.Database.DBRepository.Base;
using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FINO.CoreProject.Repository.Base;

namespace FINO.CoreProject.Database.DBRepository.Execution.Base
{
    public interface DBExecution<TRepository> : BaseRepository
        where TRepository : BaseDBContext
    {
       TRepository Repository { get; }
        new DBExecution<TRepository> New(TRepository repository);
    }

    public abstract class DBExecutionImpl<TRepository> : BaseRepositoryImpl, DBExecution<TRepository>
        where TRepository : BaseDBContext
    {
       public TRepository Repository { get; private set; }
        public new DBExecution<TRepository> New(TRepository repository)
        {
            this.Repository = repository;
            return this;
        }
    }
}
