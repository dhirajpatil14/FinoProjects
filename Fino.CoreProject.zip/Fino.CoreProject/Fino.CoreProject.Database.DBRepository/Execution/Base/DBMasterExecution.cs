﻿using FINO.CoreProject.Database.DBRepository.Base;
using FINO.CoreProject.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Database.DBRepository.Execution.Base
{
    public interface DBMasterExecution<TRepository, TData, TId> : DBExecution<TRepository>
    where TData : BaseEntityForMaster<TId>
    where TRepository : MasterDBContext<TData,TId>
    { 
             new DBMasterExecution<TRepository, TData, TId> New(TRepository repository);
    } 

    public abstract class DBMasterExecutionImpl<TRepository,TData, TId> : DBExecutionImpl<TRepository> 
        , DBMasterExecution<TRepository, TData, TId>
    where TData : BaseEntityForMaster<TId>
    where TRepository : MasterDBContext<TData, TId>
    {
        public new DBMasterExecution<TRepository, TData, TId> New(TRepository repository)
        {
            base.New(repository);
            return this;
        }
    }
}
