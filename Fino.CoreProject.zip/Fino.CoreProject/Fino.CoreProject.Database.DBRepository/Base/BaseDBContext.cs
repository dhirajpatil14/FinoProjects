﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Repository.Base;
namespace FINO.CoreProject.Database.DBRepository.Base
{
    public interface BaseDBContext : BaseRepositoryWithLogger
    {
        String ConnectionString { get; }
        new BaseDBContext New(String connectionString, ILogger logger);
    }

    public abstract class BaseDBContextImpl : BaseRepositoryWithLoggerImpl , BaseDBContext
    {
        public String ConnectionString { get; private set; }
        public new BaseDBContext New(String connectionString, ILogger logger)
        {
            base.New(logger);
            this.ConnectionString = connectionString;
            return this;
        }
    }
}
