﻿using FINO.CoreProject.Entity.Base;
using Microsoft.Extensions.Logging;

namespace FINO.CoreProject.Database.DBRepository.Base
{
    public interface MasterDBContext<TData, TId> : BaseDBContext
        where TData : BaseEntityForMaster<TId>
    {
        TId Save(TData data);
        TId Update(TData data);
        TId Delete(TId id);
        TData Get(TId id);
        IEnumerable<TData> GetAllActive();
        IEnumerable<TData> GetAll();

        new MasterDBContext<TData,TId> New(String connectionString, ILogger logger);

    }

    public abstract class MasterDBContextImpl<TData, TId> : BaseDBContextImpl
        , MasterDBContext<TData, TId>
        where TData : BaseEntityForMaster<TId>
    {
        public abstract TId Delete(TId id);
        public abstract TData Get(TId id);

        public abstract IEnumerable<TData> GetAll();

        public abstract IEnumerable<TData> GetAllActive();

        public abstract TId Save(TData data);

        public abstract TId Update(TData data);

        public new MasterDBContext<TData,TId> New(String connectionString,ILogger logger)
        {
            base.New(connectionString,logger);
            return this;
        } 
    }
}
