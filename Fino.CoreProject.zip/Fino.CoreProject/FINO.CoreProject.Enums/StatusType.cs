﻿namespace FINO.CoreProject.Enums
{
    public enum StatusType
    {
        Active = 0,
        Inactive = 1,
        Deleted = 2,
    }
}
