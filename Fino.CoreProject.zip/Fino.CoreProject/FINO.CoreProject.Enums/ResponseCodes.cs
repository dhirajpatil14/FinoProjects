﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Enums
{
    public enum ResponseCodes
    {
        Successful = 0,
        Failed = 1,
        TimeOut = 2,
        ApplicationError = 3,
        SystemError = 4,
        TPError=5,
        TPTimeOut=6,
        UnhandledException = 7,
        ConnectivityError = 8,
        DBError = 9,
        PartialSuccessful = 10,
        PartialFailed = 11,
        DBTimeOut = 12,

    }
}
