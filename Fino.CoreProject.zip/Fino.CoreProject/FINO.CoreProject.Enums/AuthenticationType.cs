﻿
namespace FINO.CoreProject.Enums
{
    public enum AuthenticationTypes
    {
        JWTToken = 0,
        BearerToken = 1,
        Windows = 2,
        Cache = 3,
    }
}
