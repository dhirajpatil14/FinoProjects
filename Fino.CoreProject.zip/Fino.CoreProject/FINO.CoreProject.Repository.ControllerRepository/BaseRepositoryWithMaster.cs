﻿using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Entity.RequestResponse.Request;
using FINO.CoreProject.Entity.RequestResponse.Response;
using FINO.CoreProject.Repository.Base;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.ControllerRepository
{
    public interface BaseRepositoryWithMaster<TModel,TId> : BaseRepositoryWithLogger
        where TModel : BaseEntityForMaster<TId>
    {
        Task<Response<TModel>> Get(Request<TId> request);
        Task<Response<IEnumerable<TModel>>> GetAll();
        Task<Response<TModel>> Save(Request<TModel> request);

        Task<Response<TModel>> Update(Request<TModel> request);

        Task<Boolean> Delete(Request<TId> request);

        new BaseRepositoryWithMaster<TModel, TId> New(ILogger logger);
    }

}
