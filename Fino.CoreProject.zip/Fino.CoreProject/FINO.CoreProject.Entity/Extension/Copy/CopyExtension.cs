﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FINO.CoreProject.Core;

namespace FINO.CoreProject.Entity.Base.Extension.Copy
{
    public static class CopyExtension
    {
        public static TDestination ? Copy<TDestination>(this BaseEntity me,  TDestination destination)
        {
            return CopyClass.Copy<Object, TDestination>(me, destination);
        }

        public static TDestination Copy<TDestination>(this BaseEntity me) where TDestination : new() => Copy(me, new TDestination());

    }
}
