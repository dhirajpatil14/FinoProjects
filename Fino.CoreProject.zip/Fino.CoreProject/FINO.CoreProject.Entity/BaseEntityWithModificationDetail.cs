﻿
namespace FINO.CoreProject.Entity.Base
{
    public interface BaseEntityWithModificationDetail<T> : BaseEntityWithUniqueId<T>
    {
        T createdBy { get; set; }
        T modifiedBy { get; set; }
        DateTime createdDate { get; set; }
        DateTime modifiedDate { get; set; }
        BaseEntityWithModificationDetail<T> New();
    }
    public abstract class BaseEntityWithModificationDetailImpl<T>: BaseEntityWithUniqueIdImpl<T>, BaseEntityWithModificationDetail<T>
    {
        public required T createdBy { get; set; }
        public T ? modifiedBy { get; set; }
        public DateTime createdDate { get; set; }
        public DateTime modifiedDate { get; set; }

        public BaseEntityWithModificationDetail<T> New()
        {
            this.createdDate = this.modifiedDate = DateTime.UtcNow;
            return (BaseEntityWithModificationDetail<T>) this;
        }
    }
}
