﻿using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Collections;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FINO.CoreProject.Entity.Base
{
    public interface BaseEntity : IDisposable, ICloneable
    {
        T deepClone<T>();
        Task<String> ToStringAsync();
    }
}
