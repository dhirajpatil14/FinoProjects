﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Base
{
    [Serializable]
    public abstract class EntityBaseImpl : BaseEntity
    {
        public EntityBaseImpl() { }

        public void Dispose() { }
        public dynamic Clone() => this.MemberwiseClone();

        public T deepClone<T>() => (T)this.MemberwiseClone();

        public abstract override string ToString();
        public abstract Task<string> ToStringAsync();
    }
}
