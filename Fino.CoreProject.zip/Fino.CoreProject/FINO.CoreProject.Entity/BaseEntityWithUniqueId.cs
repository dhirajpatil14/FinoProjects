﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Base
{
    public interface BaseEntityWithUniqueId <T>: BaseEntity
    {
        T  Id { get; set; }
    }

    public abstract class BaseEntityWithUniqueIdImpl<T> : BaseEntityImpl ,BaseEntityWithUniqueId<T>
    {
        public required T Id { get; set; }
    }
}
