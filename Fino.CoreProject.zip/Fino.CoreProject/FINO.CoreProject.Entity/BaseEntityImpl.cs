﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FINO.CoreProject.Entity.Base
{
    public abstract class BaseEntityImpl : EntityBaseImpl
    {
        public override string ToString() => ToStringFormater().Result;
        public override async Task<String> ToStringAsync() =>  await ToStringFormater();
        private String ObjectToString(dynamic data, Type dataType)
        {
            String result = String.Empty;
            if (dataType.IsPrimitive
                    || dataType == typeof(string)
                    || dataType == typeof(String)
                    || dataType == typeof(DateTime))
            {
                result = String.Format("{0}", this.concatDoubleQouts(data.ToString()));
            }
            else if (data is BaseEntity)
            {
                result = data.ToString();
            }
            else if (dataType == typeof(Guid))
            {
                result = String.Format("{0}", this.concatDoubleQouts(Convert.ToString(data)));
            }
            else if (dataType.IsEnum)
            {
                result = String.Format("\"({0}){1}\"", Enum.Format(dataType, data, "D"), Enum.Format(dataType, data, "F"));
            }
            else if (dataType.IsArray || (dataType.IsGenericType && data is IEnumerable && data is not IDictionary))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("[");
                foreach (var val in data)
                {
                    if (builder.Length > 1) builder.Append(",");
                    builder.AppendFormat("{0}", ObjectToString(val, val.GetType()));
                }
                builder.Append("]");
                result = builder.ToString();
            }
            else if (dataType.IsGenericType && dataType.GetGenericTypeDefinition() == typeof(KeyValuePair<,>))
            {
                var key = dataType.GetProperty("Key").GetValue(data, null);
                var value = dataType.GetProperty("Value").GetValue(data, null);
                return String.Format("{0} : {1}", this.concatDoubleQouts(key), ObjectToString(value, value.GetType()));
            }
            else if (dataType.IsGenericType && data is IDictionary)
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("[");
                foreach (var val in data)
                {
                    if (builder.Length > 1) builder.Append(",");
                    var key = val.GetType().GetProperty("Key").GetValue(val, null);
                    var value = val.GetType().GetProperty("Value").GetValue(val, null);
                    builder.AppendFormat("{0}:{1}", this.concatDoubleQouts(key), ObjectToString(value, value.GetType()));
                }
                builder.Append("]");
                result = builder.ToString();
            }
            else if(data !=null)
            {
                result = JsonSerializer.Serialize(data);
            }
            else
            {
                result = String.Empty;
            }
            return result;
        }
        private async Task<String> ToStringFormater()
        {
            return await Task.Run<String>(() =>
            {
                StringBuilder builder = new StringBuilder();
                try 
                { 
                    builder.Append("{");
                    builder.AppendFormat("{0}:", this.concatDoubleQouts("class"));
                    builder.Append("{");
                    builder.AppendFormat("\"{0},{1}\"", this.GetType().Assembly.FullName, this.GetType().FullName);
                    builder.Append("}");
                    builder.AppendFormat(",{0}:", this.concatDoubleQouts("properties"));
                    builder.Append("{");
                    var myProperties = this.GetType().GetProperties().AsEnumerable();
                    dynamic propertyvalue;
                    foreach (var property in myProperties)
                    {
                        if (property != myProperties.First())
                        {
                            builder.Append(",");
                        }
                        propertyvalue = property.GetValue(this);
                        builder.AppendFormat("{0}:{1}", this.concatDoubleQouts(property.Name), ObjectToString(propertyvalue, property.PropertyType));
                    }
                    builder.Append("}}");
                    return builder.ToString();
                }
                finally
                {
                    builder = null;
                }
            });
        }

        private String concatDoubleQouts(String data) => String.Format("\"{0}\"", data);
    }
}
