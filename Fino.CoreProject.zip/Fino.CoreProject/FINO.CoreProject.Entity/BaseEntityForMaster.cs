﻿using FINO.CoreProject.Enums; 

namespace FINO.CoreProject.Entity.Base
{
    public interface BaseEntityForMaster<T> : BaseEntityWithModificationDetail<T>
    {
        StatusType Status { get; set; }
        new BaseEntityForMaster<T> New();
    }
    public abstract class BaseEntityForMasterImpl<T> : BaseEntityWithModificationDetailImpl<T>, BaseEntityForMaster<T>
    {
        public StatusType Status { get; set; }
        public new BaseEntityForMaster<T> New()
        {
            this.Status = StatusType.Active;
            this.Id = default(T);
            base.New();
            return this;
        }
    }
}
