﻿using Microsoft.Extensions.Logging;

namespace FINO.CoreProject.Repository.Base
{
    public interface BaseRepository : IDisposable
    {
        dynamic New();
    }
}
