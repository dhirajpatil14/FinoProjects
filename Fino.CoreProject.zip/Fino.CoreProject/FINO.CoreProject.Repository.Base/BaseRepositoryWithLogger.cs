﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.Base
{
    public interface BaseRepositoryWithLogger : BaseRepository
    {
        ILogger Logger {  get; }
       dynamic New(ILogger logger);
    }

    public abstract class BaseRepositoryWithLoggerImpl : BaseRepositoryImpl, BaseRepositoryWithLogger
    {
        public ILogger Logger { get; private set;  }
        
        public dynamic New(ILogger logger)
        {
            this.Logger = logger;
            return this;
        }

        protected override void Dispose(bool disposing)
        {
            if (this.Logger != null)
            {
                this.Logger = null;
            }
            base.Dispose(disposing);
        }
    }
}
