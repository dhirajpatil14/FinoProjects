﻿using Microsoft.Extensions.Logging;
using FINO.CoreProject.Repository.Base;
using FINO.CoreProject.Database.DBRepository.Base;
namespace FINO.CoreProject.Repository.Implementation.Execution
{
    public interface BaseRepositoryExecution<TDBRepository> : BaseRepositoryWithLogger
        where TDBRepository : BaseDBContext
    {
       TDBRepository DBRepository { get; }
        new BaseRepositoryExecution<TDBRepository> New(ILogger logger,TDBRepository dBRepository);
    }

    public abstract class BaseRepositoryExecutionImpl<TDBRepository> : BaseRepositoryWithLoggerImpl 
        , BaseRepositoryExecution<TDBRepository>
        where TDBRepository : BaseDBContext
    {
       public TDBRepository DBRepository { get; private set; }
        public new BaseRepositoryExecution<TDBRepository> New(ILogger logger, TDBRepository dBRepository)
        {
            base.New(logger);
            this.DBRepository = dBRepository;
            return this;
        }
    }
}
