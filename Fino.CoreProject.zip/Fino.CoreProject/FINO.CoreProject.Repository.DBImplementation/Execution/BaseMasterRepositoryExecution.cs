﻿using FINO.CoreProject.Entity.Base;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Repository.Implementation.Execution
{
    public interface BaseMasterRepositoryExecution<TDBRepository, TData,TId> : BaseRepositoryExecution<TDBRepository>
        where TData : BaseEntityForMaster<TId>
        where TDBRepository : FINO.CoreProject.Database.DBRepository.Base.MasterDBContext<TData,TId>
    {
        TId Save(TData data);
        TId Update(TData data);
        TId Delete(TId id);
        TData Get(TId id);
        IEnumerable<TData> GetAllActive();
        IEnumerable<TData> GetAll();

        new BaseMasterRepositoryExecution<TDBRepository, TData, TId> New(ILogger logger, TDBRepository dBRepository);
    }

    public abstract class BaseMasterRepositoryExecutionImpl<TDBRepository,TData, TId> : BaseRepositoryExecutionImpl<TDBRepository>
        ,BaseMasterRepositoryExecution<TDBRepository, TData, TId>
        where TData : BaseEntityForMaster<TId>
        where TDBRepository : FINO.CoreProject.Database.DBRepository.Base.MasterDBContext<TData, TId>

    {
        public abstract TId Delete(TId id);
        public abstract TData Get(TId id);

        public abstract IEnumerable<TData> GetAll();

        public abstract IEnumerable<TData> GetAllActive();

        public abstract TId Save(TData data);

        public abstract TId Update(TData data);

        public new BaseMasterRepositoryExecution<TDBRepository,TData, TId> New(ILogger logger, TDBRepository dBRepository)
        {
            base.New(logger, dBRepository);
            return this;
        }
    }
}
