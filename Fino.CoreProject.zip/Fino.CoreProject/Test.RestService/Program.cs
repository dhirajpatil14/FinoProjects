using FINO.CoreProject.Repository.LogRepository;
using FINO.CoreProject.ResetService.Setup;
using FINO.CoreProject.ResetService.Setup.Application;
using System.Diagnostics.Eventing.Reader;
var builder = WebApplication.CreateBuilder(args);

builder.Host.ConfigureLogging(logging =>
{
    logging.ClearProviders();
    logging.AddConsole();
    logging.AddDebug();
});

var app=SetupApplication.Initialize(SetupService.SetupBuilderApp(builder));
SetupApplication.setupDevEnvironment();
SetupApplication.useHttpsRedirection();
SetupApplication.useAuthentication();
SetupApplication.useAuthorization();

app.MapControllers();

app.Run();
