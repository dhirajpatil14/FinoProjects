using Microsoft.AspNetCore.Mvc;
using FINO.CoreProject.Entity.Base;
using FINO.CoreProject.Enums;
using FINO.CoreProject.Entity.Base.Extension.Copy;
namespace Test.RestService.Controllers
{
    public class Testentity : BaseEntityImpl
    {
        public String id { get; set; }
        public String name { get; set; }
    }

    public class TestA : BaseEntityImpl
    {
        public String id { get; set; }
        public DateTime dob { get; set; }
        public IList<Testentity> testentities { get; set; }
        public StatusType status { get; set; }

        public Testentity[] data1 { get; set; }

        public IDictionary<String , Testentity> dictTestentities { get; set; }

        public KeyValuePair<string,Testentity> keyvalue { get; set; }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };




        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            _logger.Log(LogLevel.Information, "GEt Method Started");
            //Testentity t = new Testentity { id = "1", name = "and" };

            //TestA t1 = new TestA
            //{
            //    id = "1",
            //    dob = new DateTime(),
            //    status = StatusType.Active,
            //    data1 = new Testentity[] { t },
            //    testentities = new List<Testentity>() { t },
            //    dictTestentities = new Dictionary<string, Testentity> { { "key1", t } },
            //};
            //Console.WriteLine(t1);
           
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
