﻿// See https://aka.ms/new-console-template for more information
using FINO.CoreProject.Repository.LogRepository.Implementation;
using FINO.CoreProject.Entity.Logger;
using Microsoft.Extensions.Logging;

Console.WriteLine("Hello, World!");

using ILoggerFactory loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
ILogger logger = loggerFactory.CreateLogger<Program>();

var finoLogger = new FINOLogger().New(logger, "1233", "23232", "12");
await finoLogger.Log(Loglevel: LogLevel.Error,type: ReqRespType.Request,message: "Hello World");
await finoLogger.Log<String>(Loglevel: LogLevel.Error, type: ReqRespType.Request, message: "Hello World",obj:"Hello Object");
await finoLogger.Log(Loglevel: LogLevel.Error, type: ReqRespType.Response, message: "Hello World",responseCode: 1,description:"Description Check");
await finoLogger.Log<String>(Loglevel: LogLevel.Error, type: ReqRespType.Response, message: "Hello World", responseCode: 1, description: "Description Check",obj:"String Obj");

/*
Console.WriteLine(LogFormatter.GetFormattedString(new LogEntityImpl { CorelationId = "", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now }));
Console.WriteLine(LogFormatter.GetFormattedString(new DetailLogEntityImpl { CorelationId = "", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now, Description = "Desc1", ResponseCode = -1 }));
Console.WriteLine(LogFormatter.GetFormattedString(new MessageLogEntityImpl { CorelationId = "", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now, Message = "Test Msg`" }));
Console.WriteLine(LogFormatter.GetFormattedString(new ObjectLogEntityImpl { CorelationId = "", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122",SysDateTime = DateTime.Now, Message = "Test Msg`",LogObject="{{}}" }));
Console.WriteLine(LogFormatter.GetFormattedString(new DetailLogEntityWithMessageImpl{ CorelationId = "", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now, Description = "Desc1", ResponseCode = -1 }));
Console.WriteLine(LogFormatter.GetFormattedString(new FullLogEntityImpl { CorelationId = "corel", LogLevel = LogLevel.Information, ReqRespType = ReqRespType.Request, ServerNode = "1", SessionId = "12122", SysDateTime = DateTime.Now, Description = "Desc1", ResponseCode = -1, Message = "Msg Test1", LogObject = "[{}]" }));
*/
