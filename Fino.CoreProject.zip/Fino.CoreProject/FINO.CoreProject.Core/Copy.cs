﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FINO.CoreProject.Core
{
    public static class CopyClass
    {
        public static TDestination ? Copy<TSource,TDestination>(TSource source, TDestination destination)
        {
            var sourceProperties = source.GetType().GetProperties();
            var destProperties = destination.GetType().GetProperties();

            foreach (var destpropinfo in destProperties)
            {
                var sourceprop = sourceProperties.Where(p => p.Name == destpropinfo.Name).First();
                if (sourceprop != null)
                {
                    destpropinfo.SetValue(destination, sourceprop.GetValue(source));
                }
            }
            return destination;
        }
    }
}
